#ifndef LIBUTILH
#define LIBUTILH

#pragma warning(disable:4996)
#pragma warning(disable:4267)

#include "TCP.h"
#include "Util.h"
#include "GDI.h"
#include "DIB.h"
#include "Archive.h"
#include "Rand.h"
#include "Thread.h"

#endif

