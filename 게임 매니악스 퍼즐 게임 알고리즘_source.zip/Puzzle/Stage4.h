//==============================================================
// ������ �簢������ ����� ���ֱ�

// ��������
class CRectangleShapedBlockStage : public CStage {
public:
	CCell* Cell;
	int CX, CY;
	int State, Time, DropTime;
	int L, R, T, B;
	bool PrevLever, PrevButton;

	CRectangleShapedBlockStage() : CStage(L"RECTANGLE SHAPED BLOCK") {
		Cell=new CCell();
	}

	virtual ~CRectangleShapedBlockStage() {
		delete Cell;
	}

	virtual void Init() {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();
		Cell->Init(
			"                "
			"=00000 33333   ="
			"=0 111222  3   ="
			"=  1 777244444 ="
			"=99188872554   ="
			"=9  8  7  56666="
			"=9  8     56  6="
			"=9        5    ="
			"=9        5    ="
			"=              ="
			"=              ="
			"================"
		);
		CX=xs/2;
		CY=ys-2;
		PrevLever=true;
		PrevButton=true;
		State=0;
		Time=0;
		DropTime=0;
	}

	virtual bool Move(const CInputState* is) {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();

		if (State==0) {
			if (!PrevLever) {
				if (is->Left && CX>0) CX--;
				if (is->Right && CX<xs-1) CX++;
			}
			PrevLever=is->Left||is->Right;

			if (!PrevButton && is->Button[0] && Cell->Get(CX, CY-1)==' ') {
				Cell->Set(CX, CY, '+');
			}
			PrevButton=is->Button[0];

			for (int x=1; x<xs-1; x++) {
				Cell->Set(x, 0, ' ');
			}
			for (int y=1; y<ys-1; y++) {
				for (int x=1; x<xs-1; x++) {
					if (Cell->Get(x, y)=='+') {
						char c=Cell->Get(x, y-1);
						if (c==' ') {
							Cell->Set(x, y-1, '+');
							Cell->Set(x, y, ' ');
						} else {
							Cell->Set(x, y, c);
							EraseBlock(x, y);
						} 
					}
				}
			}
			
			DropTime++;
			if (DropTime==60) {
				DropTime=0;
				int x, y;
				for (x=1; x<xs-1; x++) {
					if (Cell->Get(x, ys-3)!=' ') break;
				}
				if (x==xs-1) {
					for (y=ys-3; y>0; y--) {
						for (x=1; x<xs-1; x++) {
							Cell->Set(x, y, Cell->Get(x, y-1));
						}
					}
				}
			}
		}
		
		if (State==1) {
			Time++;
			if (Time==30) {
				for (int y=T; y<B; y++) {
					for (int x=L; x<R; x++) {
						Cell->Set(x, y, ' ');
					}
				}
				State=0;
			}
		}
		
		return true;
	}
	
	void EraseBlock(int x, int y) {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();
		char c=Cell->Get(x, y);
		
		for (L=x; Cell->Get(L-1, y)==c; L--) ;
		for (R=x+1; Cell->Get(R, y)==c; R++) ;
		for (T=y; Cell->Get(x, T-1)==c; T--) ;
		for (B=y+1; Cell->Get(x, B)==c; B++) ;

		for (y=T; y<B; y++) {
			for (x=L; x<R; x++) {
				if (Cell->Get(x, y)!=c) break;
			}
			if (x<R) break;
		}

		if (y==B) {
			for (x=L; x<R; x++) {
				if (Cell->Get(x, T-1)==c || Cell->Get(x, B)==c) break;
			}
			for (y=T; y<B; y++) {
				if (Cell->Get(L-1, y)==c || Cell->Get(R, y)==c) break;
			}
			if (x==R && y==B) {
				for (int y=T; y<B; y++) {
					for (int x=L; x<R; x++) {
						Cell->Set(x, y, '*');
					}
				}
				Time=0;
				State=1;
			}
		}
	}

	virtual void Draw() {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();
		float 
			sw=Game->GetGraphics()->GetWidth()/xs,
			sh=Game->GetGraphics()->GetHeight()/ys;
		for (int y=0; y<ys; y++) {
			for (int x=0; x<xs; x++) {
				if (Cell->Get(x, y)=='=') {
					Game->Texture[TEX_FLOOR]->Draw(
						x*sw, y*sh, sw, sh, 0, 0, 1, 1, COL_BLACK);
				}
			}
		}
		for (int y=1; y<ys-1; y++) {
			for (int x=1; x<xs-1; x++) {
				char c=Cell->Get(x, y);
				if (c=='+') {
					Game->Texture[TEX_OBJECT]->Draw(
						x*sw, y*sh, sw, sh, 0, 0, 1, 1, COL_LGRAY);
				} else
				if (c!=' ') {
					static const float gap=0.1f;
					float l=x, r=x+1, t=y, b=y+1;
					if (c!=Cell->Get(x-1, y)) l+=gap;
					if (c!=Cell->Get(x+1, y)) r-=gap;
					if (c!=Cell->Get(x, y-1)) t+=gap;
					if (c!=Cell->Get(x, y+1)) b-=gap;

					float f=(float)Time/30;
					D3DCOLOR color=COL_BLACK;
					if (c=='*') color=D3DXCOLOR(f, f, f, 1);
					Game->Texture[TEX_FILL]->Draw(
						l*sw, t*sh, (r-l)*sw, (b-t)*sh, 0, 0, 1, 1, color);
				}
			}
		}
		Game->Texture[TEX_MAN]->Draw(
			CX*sw, CY*sh, sw, sh, 0, 0, 1, 1, COL_BLACK);
	}
};

//==============================================================
// ������ ������Ű��

// ��������
class CTransformedBlockStage : public CStage {
public:
	CCell* StageCell;
	CCell* BlockCell;
	int CX, CY, State, Time, DropTime;
	bool PrevLever, PrevUp, PrevButton;

	CTransformedBlockStage() : CStage(L"TRANSFORMED BLOCK") {
		StageCell=new CCell();
		BlockCell=new CCell(3, StageCell->GetYSize());
	}

	virtual ~CTransformedBlockStage() {
		delete StageCell;
		delete BlockCell;
	}

	virtual void Init() {
		int xs=StageCell->GetXSize(), ys=StageCell->GetYSize();
		StageCell->Init(
			"                "
			"================"
			"=######### ####="
			"= ##  ###  # ##="
			"=  #   #   #   ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"================"
		);
		PrevLever=false;
		PrevButton=false;
		State=0;
	}

	virtual bool Move(const CInputState* is) {
		int 
			xs=StageCell->GetXSize(), ys=StageCell->GetYSize(),
			bxs=BlockCell->GetXSize(), bys=BlockCell->GetYSize();

		if (State==0) {
			BlockCell->Clear(' ');
			for (int x=0; x<bxs; x++) {
				BlockCell->Set(x, bys-1, '#');
			}
			CX=(xs-bxs)/2;
			CY=-1;
			if (!StageCell->Hit(CX, CY, BlockCell)) {
				DropTime=0;
				PrevUp=true;
				State=1;
			}
		}
		
		if (State==1) {
			if (!PrevLever) {
				if (is->Left && !StageCell->Hit(CX-1, CY, BlockCell)) CX--;
				if (is->Right && !StageCell->Hit(CX+1, CY, BlockCell)) CX++;
			}
			PrevLever=is->Left|is->Right;

			DropTime++;
			if (DropTime==60 || (!PrevUp && is->Up)) {
				DropTime=0;
				if (!StageCell->Hit(CX, CY-1, BlockCell)) {
					CY--;
				} else {
					StageCell->Merge(CX, CY, BlockCell);
					State=0;
					for (int y=2; y<ys-1; y++) {
						int x;
						for (x=1; x<xs-1; x++) {
							if (StageCell->Get(x, y)!='#') break;
						}
						if (x==xs-1) {
							for (x=1; x<xs-1; x++) {
								StageCell->Set(x, y, '+');
							}
							Time=0;
							State=2;
						}
					}
				}
			}
			if (!is->Up) PrevUp=false;

			if (!PrevButton) {
				int x;
				for (x=0; !is->Button[x] && x<bxs; x++) ;
				if (x<bxs) {
					for (int y=0; y<bys; y++) {
						if (
							BlockCell->Get(x, y)=='#' && 
							StageCell->Get(CX+x, CY+y-1)==' '
						) {
							BlockCell->Set(x, y-1, '#');
						}
					}
				}
			}
			PrevButton=false;
			for (int i=0; i<bxs; i++) {
				PrevButton=PrevButton||is->Button[i];
			}
		}
		
		if (State==2) {
			Time++;
			if (Time==30) {
				for (int y=ys-3; y>=2; y--) {
					if (StageCell->Get(1, y)=='+') {
						for (int x=1; x<xs-1; x++) {
							for (int i=y; i<ys-2; i++) {
								StageCell->Set(x, i, StageCell->Get(x, i+1));
							}
							StageCell->Set(x, ys-2, ' ');
						}
					}
				}
				State=0;
			}
		}
		
		return true;
	}
	
	virtual void Draw() {
		int xs=StageCell->GetXSize(), ys=StageCell->GetYSize();
		float 
			sw=Game->GetGraphics()->GetWidth()/xs,
			sh=Game->GetGraphics()->GetHeight()/ys;
		for (int y=0; y<ys; y++) {
			for (int x=0; x<xs; x++) {
				float f=(float)Time/30;
				switch (StageCell->Get(x, y)) {
					case '=':
						Game->Texture[TEX_DROP_FLOOR]->Draw(
							x*sw, y*sh, sw, sh, 0, 0, 1, 1, COL_BLACK);
						break;
					case '#':
						Game->Texture[TEX_OBJECT]->Draw(
							x*sw, y*sh, sw, sh, 0, 0, 1, 1, COL_BLACK);
						break;
					case '+':
						Game->Texture[TEX_OBJECT]->Draw(
							x*sw, y*sh, sw, sh, 60, 0, 1, 1, 
							D3DXCOLOR(f, f, f, 1));
						break;
				}
				if (State==1 && BlockCell->Get(x-CX, y-CY)=='#') {
					Game->Texture[TEX_OBJECT]->Draw(
						x*sw, y*sh, sw, sh, 60, 0, 1, 1, COL_LGRAY);
				}
			}
		}
	}
};

//==============================================================
// ������ �ε��� �μ���

#define STRUCK_BLOCK_COUNT 2

// ��������
class CStruckBlockStage : public CStage {
public:
	CCell* Cell;
	int CX, CY, Type, State, Time, DropTime;
	bool PrevLever, PrevDown;

	CStruckBlockStage() : CStage(L"STRUCK BLOCK") {
		Cell=new CCell();
	}

	virtual ~CStruckBlockStage() {
		delete Cell;
	}

	virtual void Init() {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();
		Cell->Init(
			"                "
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=      2       ="
			"=   01022      ="
			"=  010103332   ="
			"= 00111101112  ="
			"================"
		);
		PrevLever=false;
		Type=0;
		State=0;
	}

	virtual bool Move(const CInputState* is) {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();

		if (State==0) {
			CX=xs/2;
			CY=0;
			Type=Rand.Int31()%STRUCK_BLOCK_COUNT;
			DropTime=0;
			PrevDown=true;
			State=1;
		}
		
		if (State==1) {
			if (!PrevLever) {
				if (is->Left && Cell->Get(CX-1, CY)==' ') CX--;
				if (is->Right && Cell->Get(CX+1, CY)==' ') CX++;
			}
			PrevLever=is->Left|is->Right;

			DropTime++;
			if (DropTime==60 || (!PrevDown && is->Down)) {
				DropTime=0;
				if (Cell->Get(CX, CY+1)==' ') {
					CY++;
				} else {
					Time=0;
					State=0;
					Cell->Set(CX, CY, '0'+Type);
					Strike(CX, CY+1, '0'+Type);
				}
			}
			if (!is->Down) PrevDown=false;
		}
		
		if (State==2) {
			Time++;
			if (Time==30) {
				State=0;
				for (int y=0; y<ys; y++) {
					for (int x=0; x<xs; x++) {
						char c=Cell->Get(x, y);
						if (c&0x80) {
							c&=0x7f;
							if ('0'<=c && c<'0'+STRUCK_BLOCK_COUNT) {
								Cell->Set(x, y, c+STRUCK_BLOCK_COUNT);
							} else {
								Cell->Set(x, y, ' ');
								Time=0;
								State=3;
							}
						}
					}
				}
			}
		}
		
		if (State==3) {
			Time++;
			if (Time==30) {
				for (int x=1; x<xs-1; x++) {
					for (int i=1; i<ys-1; i++) {
						if (Cell->Get(x, i)==' ') {
							for (int y=i; y>0; y--) {
								Cell->Set(x, y, Cell->Get(x, y-1));
							}
							Cell->Set(x, 0, ' ');
						}
					}
				}
				State=0;
			}
		}
		
		return true;
	}
	
	void Strike(int x, int y, char c) {
		char d=Cell->Get(x, y);
		if (d==c || d==c+STRUCK_BLOCK_COUNT) {
			Cell->Set(x, y, d|0x80);
			for (int i=-1; i<=1; i++) {
				for (int j=-1; j<=1; j++) {
					if (i!=0 || j!=0) {
						Strike(x+i, y+j, c);
					}
				}
			}
			State=2;
		}
	}
	
	virtual void Draw() {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();
		float 
			sw=Game->GetGraphics()->GetWidth()/xs,
			sh=Game->GetGraphics()->GetHeight()/ys;
		for (int y=0; y<ys; y++) {
			for (int x=0; x<xs; x++) {
				char c=Cell->Get(x, y);
				if (c=='=') {
					Game->Texture[TEX_DROP_FLOOR]->Draw(
						x*sw, y*sh, sw, sh, 0, 0, 1, 1, COL_BLACK);
				} else
				if (c&0x80) {
					float f=(float)Time/30;
					Game->Texture[TEX_BLOCK0+(c&0x7f)-'0']->Draw(
						x*sw, y*sh, sw, sh, 0, 0, 1, 1, D3DXCOLOR(f, f, f, 1));					
				} else
				if (c!=' ') {
					Game->Texture[TEX_BLOCK0+c-'0']->Draw(
						x*sw, y*sh, sw, sh, 0, 0, 1, 1, COL_BLACK);
				}
			}
		}
		if (State==1) {
			Game->Texture[TEX_BLOCK0+Type]->Draw(
				CX*sw, CY*sh, sw, sh, 60, 0, 1, 1, COL_LGRAY);
		}
	}
};

//==============================================================
// ���������� ȸ����Ű��

#define ROTATED_STAGE_SIZE 8

// ��������
class CRotatedStageStage : public CStage {
public:
	CCell* Cell;
	int State;
	bool PrevLever;

	CRotatedStageStage() : CStage(L"ROTATED STAGE") {
		Cell=new CCell();
	}

	virtual ~CRotatedStageStage() {
		delete Cell;
	}

	virtual void Init() {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();
		Cell->Init(
			"                "
			"   ==========   "
			"   =        =   "
			"   =        =   "
			"   =        =   "
			"   =        =   "
			"   =        =   "
			"   =   101  =   "
			"   =  1011  =   "
			"   = 0001011=   "
			"   ==========   "
			"                "
		);
		PrevLever=false;
		State=0;
	}

	virtual bool Move(const CInputState* is) {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();
		int rx=4, ry=2, rs=8;

		if (State==0) {
			if (!PrevLever && is->Left) {
				for (int y=0; y<rs/2; y++) {
					for (int x=0; x<rs/2; x++) {
						Cell->Swap(rx+x, ry+y, rx+rs-1-y, ry+x);
						Cell->Swap(rx+rs-1-y, ry+x, rx+rs-1-x, ry+rs-1-y);
						Cell->Swap(rx+rs-1-x, ry+rs-1-y, rx+y, ry+rs-1-x);
					}
				}
				Time=0;
				State=1;
			} else
			if (!PrevLever && is->Right) {
				for (int y=0; y<rs/2; y++) {
					for (int x=0; x<rs/2; x++) {
						Cell->Swap(rx+rs-1-x, ry+rs-1-y, rx+y, ry+rs-1-x);
						Cell->Swap(rx+rs-1-y, ry+x, rx+rs-1-x, ry+rs-1-y);
						Cell->Swap(rx+x, ry+y, rx+rs-1-y, ry+x);
					}
				}
				Time=0;
				State=1;
			}
			PrevLever=is->Left||is->Right;
		}
		
		if (State==1) {
			Time++;
			if (Time==30) {
				for (int x=rx; x<rx+rs; x++) {
					for (int y=ry; y<ry+rs; y++) {
						if (Cell->Get(x, y)==' ') {
							for (int i=y; i>ry; i--) {
								Cell->Set(x, i, Cell->Get(x, i-1));
							}
							Cell->Set(x, ry, ' ');
						}
					}
				}
				State=0;
			}
		}
		
		return true;
	}
	
	virtual void Draw() {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();
		float 
			sw=Game->GetGraphics()->GetWidth()/xs,
			sh=Game->GetGraphics()->GetHeight()/ys;
		for (int y=0; y<ys; y++) {
			for (int x=0; x<xs; x++) {
				char c=Cell->Get(x, y);
				if (c=='=') {
					Game->Texture[TEX_DROP_FLOOR]->Draw(
						x*sw, y*sh, sw, sh, 0, 0, 1, 1, COL_BLACK);
				} else
				if (c!=' ') {
					Game->Texture[TEX_BLOCK0+c-'0']->Draw(
						x*sw, y*sh, sw, sh, 0, 0, 1, 1, COL_BLACK);
				}
			}
		}
	}
};

//==============================================================
// ���� ���� ���ֱ�

#define FOOD_BLOCK_COUNT 2

// ��������
class CFoodBlockStage : public CStage {
public:
	CCell* Cell;
	int CX, CY, Type, State, Time, DropTime;
	bool PrevLever, PrevDown;

	CFoodBlockStage() : CStage(L"FOOD BLOCK") {
		Cell=new CCell();
	}

	virtual ~CFoodBlockStage() {
		delete Cell;
	}

	virtual void Init() {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();
		Cell->Init(
			"                "
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=      0       ="
			"=   01030 2    ="
			"=  010101110   ="
			"= 301121011103 ="
			"================"
		);
		PrevLever=false;
		Type=0;
		State=0;
	}

	virtual bool Move(const CInputState* is) {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();

		if (State==0) {
			CX=xs/2;
			CY=0;
			Type=Rand.Int31()%(FOOD_BLOCK_COUNT*2);
			DropTime=0;
			PrevDown=true;
			State=1;
		}
		
		if (State==1) {
			if (!PrevLever) {
				if (is->Left && Cell->Get(CX-1, CY)==' ') CX--;
				if (is->Right && Cell->Get(CX+1, CY)==' ') CX++;
			}
			PrevLever=is->Left||is->Right;

			DropTime++;
			if (DropTime==60 || (!PrevDown && is->Down)) {
				DropTime=0;
				if (Cell->Get(CX, CY+1)==' ') {
					CY++;
				} else {
					Cell->Set(CX, CY, '0'+Type);
					State=2;
				}
			}
			if (!is->Down) PrevDown=false;
		}
		
		if (State==2) {
			Time=0;
			State=0;
			for (int y=0; y<ys; y++) {
				for (int x=0; x<xs; x++) {
					char eater=Cell->Get(x, y);
					if (
						'0'+FOOD_BLOCK_COUNT<=eater &&
						eater<'0'+FOOD_BLOCK_COUNT*2
					) {
						char food=eater-FOOD_BLOCK_COUNT;
						if (
							(Cell->Get(x-1, y)&0x7f)==food ||
							(Cell->Get(x+1, y)&0x7f)==food ||
							(Cell->Get(x, y-1)&0x7f)==food ||
							(Cell->Get(x, y+1)&0x7f)==food
						) {
							Cell->Set(x, y, eater|0x80);
							Eat(x-1, y, food);
							Eat(x+1, y, food);
							Eat(x, y-1, food);
							Eat(x, y+1, food);
							State=3;
						}
					}
				}
			}
		}

		if (State==3) {
			Time++;
			if (Time==30) {
				for (int y=0; y<ys; y++) {
					for (int x=0; x<xs; x++) {
						if (Cell->Get(x, y)&0x80) {
							Cell->Set(x, y, ' ');
						}
					}
				}
				Time=0;
				State=4;
			}
		}
		
		if (State==4) {
			Time++;
			if (Time==30) {
				for (int x=0; x<xs; x++) {
					for (int i=0; i<ys; i++) {
						if (Cell->Get(x, i)==' ') {
							for (int y=i; y>0; y--) {
								Cell->Set(x, y, Cell->Get(x, y-1));
							}
							Cell->Set(x, 0, ' ');
						}
					}
				}
				State=2;
			}
		}
		
		return true;
	}

	void Eat(int x, int y, char food) {
		char c=Cell->Get(x, y);
		if (c==food) {
			Cell->Set(x, y, c|0x80);
			Eat(x-1, y, food);
			Eat(x+1, y, food);
			Eat(x, y-1, food);
			Eat(x, y+1, food);
		}
	}
	
	virtual void Draw() {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();
		float 
			sw=Game->GetGraphics()->GetWidth()/xs,
			sh=Game->GetGraphics()->GetHeight()/ys;
		int texture[]={TEX_FISH, TEX_MUSHROOM, TEX_ENEMY0, TEX_ENEMY1};
		for (int y=0; y<ys; y++) {
			for (int x=0; x<xs; x++) {
				char c=Cell->Get(x, y);
				if (c=='=') {
					Game->Texture[TEX_DROP_FLOOR]->Draw(
						x*sw, y*sh, sw, sh, 0, 0, 1, 1, COL_BLACK);
				} else
				if (c&0x80) {
					float f=(float)Time/30;
					Game->Texture[texture[(c&0x7f)-'0']]->Draw(
						x*sw, y*sh, sw, sh, 0, 0, 1, 1, D3DXCOLOR(f, f, f, 1));					
				} else
				if (c!=' ') {
					Game->Texture[texture[c-'0']]->Draw(
						x*sw, y*sh, sw, sh, 0, 0, 1, 1, COL_BLACK);
				}
			}
		}
		if (State==1) {
			Game->Texture[texture[Type]]->Draw(
				CX*sw, CY*sh, sw, sh, 0, 0, 1, 1, COL_LGRAY);
		}
	}
};

//==============================================================
// �������� �ѷ��� ���ֱ�

// ��������
class CSurroundingBlockStage : public CStage {
public:
	CCell* Cell;
	int CX, CY, State, Time, DropTime;
	char Type;
	bool PrevLever, PrevDown;

	CSurroundingBlockStage() : CStage(L"SURROUNDING BLOCK") {
		Cell=new CCell();
	}

	virtual ~CSurroundingBlockStage() {
		delete Cell;
	}

	virtual void Init() {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();
		Cell->Init(
			"                "
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=           +  ="
			"=    +      #  ="
			"= +# #+   # +# ="
			"= ##+#++# + ## ="
			"================"
		);
		PrevLever=false;
		Type='#';
		State=0;
	}

	virtual bool Move(const CInputState* is) {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();

		if (State==0) {
			CX=xs/2;
			CY=0;
			Type=(Rand.Int31()%2)?'#':'+';
			DropTime=0;
			PrevDown=true;
			State=1;
		}
		
		if (State==1) {
			if (!PrevLever) {
				if (is->Left && Cell->Get(CX-1, CY)==' ') CX--;
				if (is->Right && Cell->Get(CX+1, CY)==' ') CX++;
			}
			PrevLever=is->Left||is->Right;

			DropTime++;
			if (DropTime==60 || (!PrevDown && is->Down)) {
				DropTime=0;
				if (Cell->Get(CX, CY+1)==' ') {
					CY++;
				} else {
					Cell->Set(CX, CY, Type);
					State=2;
				}
			}
			if (!is->Down) PrevDown=false;
		}
		
		if (State==2) {
			Time=0;
			State=0;
			for (int y=0; y<ys; y++) {
				for (int x=0; x<xs; x++) {
					if (
						Cell->Get(x, y)=='+' && 
						Count(x, y)==0
					) {
						Erase(x, y);
						State=3;
					}
				}
			}
			for (int y=0; y<ys; y++) {
				for (int x=0; x<xs; x++) {
					Cell->Set(x, y, Cell->Get(x, y)&0x7f);
				}
			}
		}

		if (State==3) {
			Time++;
			if (Time==30) {
				for (int y=0; y<ys; y++) {
					for (int x=0; x<xs; x++) {
						if (Cell->Get(x, y)&0x40) {
							Cell->Set(x, y, ' ');
						}
					}
				}
				Time=0;
				State=4;
			}
		}
		
		if (State==4) {
			Time++;
			if (Time==30) {
				for (int x=0; x<xs; x++) {
					for (int i=0; i<ys; i++) {
						if (Cell->Get(x, i)==' ') {
							for (int y=i; y>0; y--) {
								Cell->Set(x, y, Cell->Get(x, y-1));
							}
							Cell->Set(x, 0, ' ');
						}
					}
				}
				State=2;
			}
		}
		
		return true;
	}

	int Count(int x, int y) {
		char c=Cell->Get(x, y);
		if (c=='+') {
			Cell->Set(x, y, c|0x80);
			return Count(x-1, y)+Count(x+1, y)+Count(x, y-1)+Count(x, y+1);
		} else
		if (c==' ') {
			return 1;
		} else {
			return 0;
		}
	}

	void Erase(int x, int y) {
		char c=Cell->Get(x, y);
		if (c==(char)('+'|0x80)) {
			Cell->Set(x, y, c|0x40);
			Erase(x-1, y);
			Erase(x+1, y);
			Erase(x, y-1);
			Erase(x, y+1);
		}
	}
	
	virtual void Draw() {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();
		float 
			sw=Game->GetGraphics()->GetWidth()/xs,
			sh=Game->GetGraphics()->GetHeight()/ys;
		for (int y=0; y<ys; y++) {
			for (int x=0; x<xs; x++) {
				char c=Cell->Get(x, y);
				int texture=TEX_VOID;
				switch (c&0x3f) {
					case '#': texture=TEX_OBJECT; break;
					case '+': texture=TEX_ITEM; break;
					case '=': texture=TEX_DROP_FLOOR; break;
				}
				if (c&0x40) {
					float f=(float)Time/30;
					Game->Texture[texture]->Draw(
						x*sw, y*sh, sw, sh, 
						0, 0, 1, 1, D3DXCOLOR(f, f, f, 1));					
				} else {
					Game->Texture[texture]->Draw(
						x*sw, y*sh, sw, sh, 
						0, 0, 1, 1, COL_BLACK);
				}
			}
		}
		if (State==1) {
			Game->Texture[Type=='#'?TEX_OBJECT:TEX_ITEM]->Draw(
				CX*sw, CY*sh, sw, sh, 0, 0, 1, 1, COL_LGRAY);
		}
	}
};

//==============================================================
// ����� ���� ���ֱ�

#define CONNECTED_BLOCK_COUNT 5
#define CONNECTED_BLOCK_ERASE 2

// ��������
class CConnectedBlockStage : public CStage {
public:
	CCell* Cell;
	int CX, CY, State, Time;
	bool PrevLever, PrevButton;

	CConnectedBlockStage() : CStage(L"CONNECTED BLOCK") {
		Cell=new CCell();
	}

	virtual ~CConnectedBlockStage() {
		delete Cell;
	}

	virtual void Init() {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();
		Cell->Init(
			"                "
			"================"
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"================"
		);
		for (int y=2; y<ys-1; y++) {
			for (int x=1; x<xs-1; x++) {
				Cell->Set(x, y, '0'+Rand.Int31()%CONNECTED_BLOCK_COUNT);
			}
		}
		PrevLever=false;
		CX=1;
		CY=2;
		State=0;
	}

	virtual bool Move(const CInputState* is) {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();

		if (State==0) {
			if (!PrevLever) {
				if (is->Left && CX>1) CX--; else
				if (is->Right && CX<xs-2) CX++; else
				if (is->Up && CY>2) CY--; else
				if (is->Down && CY<ys-2) CY++;
			}
			PrevLever=is->Left||is->Right||is->Up||is->Down;

			if (!PrevButton && is->Button[0]) {
				char c=Cell->Get(CX, CY);
				if (
					c!=' ' &&
					Erase(CX, CY, c, 0x80)>=CONNECTED_BLOCK_ERASE
				) {
					Erase(CX, CY, c|0x80, 0x40);
					Time=0;
					State=1;
				}
			}
			PrevButton=is->Button[0];
			
			for (int y=2; y<ys-1; y++) {
				for (int x=1; x<xs-1; x++) {
					Cell->Set(x, y, Cell->Get(x, y)&0x7f);
				}
			}
		}
		
		if (State==1) {
			Time++;
			if (Time==30) {
				for (int x=1; x<xs-1; x++) {
					for (int y=2; y<ys-1; y++) {
						if (Cell->Get(x, y)&0x40) {
							for (int i=y; i>2; i--) {
								Cell->Set(x, i, Cell->Get(x, i-1));
							}
							Cell->Set(x, 2, ' ');
						}
					}
				}
				Time=0;
				State=2;
			}
		}
		
		if (State==2) {
			Time++;
			if (Time==30) {
				for (int x=xs-2; x>=1; x--) {
					int y;
					for (y=2; y<ys-1 && Cell->Get(x, y)==' '; y++) ;
					if (y==ys-1) {
						for (int i=x; i<xs-2; i++) {
							for (int j=2; j<ys-1; j++) {
								Cell->Set(i, j, Cell->Get(i+1, j));
							}
						}
						for (int j=2; j<ys-1; j++) {
							Cell->Set(xs-2, j, ' ');
						}
					}
				}
				State=0;
			}
		}
		
		return true;
	}

	int Erase(int x, int y, char c, int mask) {
		if (Cell->Get(x, y)==c) {
			Cell->Set(x, y, c|mask);
			return 
				1+
				Erase(x-1, y, c, mask)+
				Erase(x+1, y, c, mask)+
				Erase(x, y-1, c, mask)+
				Erase(x, y+1, c, mask);
		}
		return 0;
	}
	
	virtual void Draw() {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();
		float 
			sw=Game->GetGraphics()->GetWidth()/xs,
			sh=Game->GetGraphics()->GetHeight()/ys;
		Game->Texture[TEX_FILL]->Draw(
			CX*sw, CY*sh, sw, sh, 0, 0, 1, 1, COL_LGRAY);
		for (int y=0; y<ys; y++) {
			for (int x=0; x<xs; x++) {
				char c=Cell->Get(x, y);
				int texture=TEX_VOID;
				if (c=='=') {
					texture=TEX_DROP_FLOOR;
				} else
				if (c!=' ') {
					texture=TEX_BALL0+(c&0x3f)-'0';
				}
				if (c&0x40) {
					float f=(float)Time/30;
					Game->Texture[texture]->Draw(
						x*sw, y*sh, sw, sh, 
						0, 0, 1, 1, D3DXCOLOR(f, f, f, 1));			
				} else {
					Game->Texture[texture]->Draw(
						x*sw, y*sh, sw, sh, 
						0, 0, 1, 1, COL_BLACK);
				}
			}
		}
	}
};

//==============================================================
// ������ ������ �߻��ϱ�

#define DRAWN_AND_SHOT_BLOCK_COUNT 5
#define DRAWN_AND_SHOT_BLOCK_ERASE 3

// ��������
class CDrawnAndShotBlockStage : public CStage {
public:
	CCell* Cell;
	int CX, CY, BX, State, Time;
	char Block;
	bool PrevLever, PrevButton;

	CDrawnAndShotBlockStage() : CStage(L"DRAWN AND SHOT BLOCK") {
		Cell=new CCell();
	}

	virtual ~CDrawnAndShotBlockStage() {
		delete Cell;
	}

	virtual void Init() {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();
		Cell->Init(
			"                "
			"================"
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"================"
		);
		for (int y=2; y<ys-1; y++) {
			for (int x=6; x<xs-1; x++) {
				Cell->Set(x, y, '0'+Rand.Int31()%DRAWN_AND_SHOT_BLOCK_COUNT);
			}
		}
		PrevLever=false;
		CX=1;
		CY=2;
		Block=' ';
		State=0;
	}

	virtual bool Move(const CInputState* is) {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();

		if (State==0) {
			if (!PrevLever) {
				if (is->Up && CY>2) CY--; else
				if (is->Down && CY<ys-2) CY++;
			}
			PrevLever=is->Up||is->Down;

			if (!PrevButton && is->Button[0]) {
				if (Block==' ') {
					int x;
					for (x=3; x<xs-1 && Cell->Get(x, CY)==' '; x++) ;
					if (x<xs-1) {
						Block=Cell->Get(x, CY);
						Cell->Set(x, CY, ' ');
						BX=x;
						State=1;
					}
				} else {
					int x;
					for (x=3; x<xs-1 && Cell->Get(x, CY)!=' '; x++) ;
					if (x<xs-1) {
						State=2;
					}
				}
			}
			PrevButton=is->Button[0];
		}
		
		if (State==1) {
			if (BX==CX+1) {
				State=3;
			} else {
				BX--;
			}
		}
		
		if (State==2) {
			if (Cell->Get(BX+1, CY)!=' ') {
				Cell->Set(BX, CY, Block);
				Block=' ';
				State=3;
			} else {
				BX++;
			}
		}

		if (State==3) {
			for (int x=3; x<xs-1; x++) {
				for (int y=2; y<ys-1; y++) {
					if (Cell->Get(x, y)==' ') {
						for (int i=y; i>2; i--) {
							Cell->Set(x, i, Cell->Get(x, i-1));
						}
						Cell->Set(x, 2, ' ');
					}
				}
			}
			for (int x=3; x<xs-1; x++) {
				int y;
				for (y=2; y<ys-1 && Cell->Get(x, y)==' '; y++) ;
				if (y==ys-1) {
					for (int i=x; i>3; i--) {
						for (int j=2; j<ys-1; j++) {
							Cell->Set(i, j, Cell->Get(i-1, j));
						}
					}
					for (int j=2; j<ys-1; j++) {
						Cell->Set(3, j, ' ');
					}
				}
			}
			State=4;
		}
		
		if (State==4) {
			State=0;
			for (int y=2; y<ys-1; y++) {
				for (int x=3; x<xs-1; x++) {
					char c=Cell->Get(x, y);
					if (
						!(c&0x80) &&
						c!=' ' &&
						Erase(x, y, c, 0x80)>=DRAWN_AND_SHOT_BLOCK_ERASE
					) {
						Erase(x, y, c|0x80, 0x40);
						Time=0;
						State=5;
					}
				}
			}
			for (int y=2; y<ys-1; y++) {
				for (int x=3; x<xs-1; x++) {
					Cell->Set(x, y, Cell->Get(x, y)&0x7f);
				}
			}
		}

		if (State==5) {
			Time++;
			if (Time==30) {
				for (int x=3; x<xs-1; x++) {
					for (int y=2; y<ys-1; y++) {
						if (Cell->Get(x, y)&0x40) {
							Cell->Set(x, y, ' ');
						}
					}
				}
				State=3;
			}
		}

		return true;
	}

	int Erase(int x, int y, char c, int mask) {
		if (Cell->Get(x, y)==c) {
			Cell->Set(x, y, c|mask);
			return 
				1+
				Erase(x-1, y, c, mask)+
				Erase(x+1, y, c, mask)+
				Erase(x, y-1, c, mask)+
				Erase(x, y+1, c, mask);
		}
		return 0;
	}
	
	virtual void Draw() {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();
		float 
			sw=Game->GetGraphics()->GetWidth()/xs,
			sh=Game->GetGraphics()->GetHeight()/ys;
		for (int y=0; y<ys; y++) {
			for (int x=0; x<xs; x++) {
				char c=Cell->Get(x, y);
				int texture=TEX_VOID;
				if (c=='=') {
					texture=TEX_DROP_FLOOR;
				} else
				if (c!=' ') {
					texture=TEX_BALL0+(c&0x3f)-'0';
				}
				if (c&0x40) {
					float f=(float)Time/30;
					Game->Texture[texture]->Draw(
						x*sw, y*sh, sw, sh, 
						0, 0, 1, 1, D3DXCOLOR(f, f, f, 1));			
				} else {
					Game->Texture[texture]->Draw(
						x*sw, y*sh, sw, sh, 
						0, 0, 1, 1, COL_BLACK);
				}
			}
		}
		Game->Texture[TEX_MAN]->Draw(
			CX*sw, CY*sh, sw, sh, 0, 0, 1, 1, COL_BLACK);
		if (Block!=' ') {
			Game->Texture[TEX_BALL0+Block-'0']->Draw(
				BX*sw, CY*sh, sw, sh, 0, 0, 1, 1, COL_LGRAY);
		}
	}
};

//==============================================================
// ������ �о ����߷� ������

#define PUSHED_AND_COLLECTED_BLOCK_COUNT 5
#define PUSHED_AND_COLLECTED_BLOCK_ERASE 3

// ��������
class CPushedAndCollectedBlockStage : public CStage {
public:
	CCell* Cell;
	int CX, CY, BX, State, Time;
	char Block;
	bool PrevLever, PrevButton;

	CPushedAndCollectedBlockStage() : CStage(L"PUSHED AND COLLECTED BLOCK") {
		Cell=new CCell();
	}

	virtual ~CPushedAndCollectedBlockStage() {
		delete Cell;
	}

	virtual void Init() {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();
		Cell->Init(
			"                "
			"================"
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"================"
			"=              ="
			"================"
		);
		for (int y=4; y<ys-3; y++) {
			for (int x=1; x<xs-6; x++) {
				Cell->Set(x, y, '0'+Rand.Int31()%PUSHED_AND_COLLECTED_BLOCK_COUNT);
			}
		}
		PrevLever=false;
		CX=xs-2;
		CY=2;
		State=0;
	}

	virtual bool Move(const CInputState* is) {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();

		if (State==0) {
			if (!PrevLever) {
				if (is->Up && CY>2) CY--; else
				if (is->Down && CY<ys-4) CY++;
			}
			PrevLever=is->Up||is->Down;

			if (!PrevButton && is->Button[0]) {
				char c=Cell->Get(1, CY);
				if (c!=' ') {
					int x;
					for (x=1; Cell->Get(x, ys-2)!=' '; x++) ;
					Cell->Set(x, ys-2, c);
					if (x==PUSHED_AND_COLLECTED_BLOCK_ERASE) {
						Time=0;
						State=1;
					}
					for (x=1; x<xs-2; x++) {
						Cell->Set(x, CY, Cell->Get(x+1, CY));
					}
				}
			}
			PrevButton=is->Button[0];
			
			for (int x=1; x<xs-1; x++) {
				for (int y=2; y<ys-3; y++) {
					if (Cell->Get(x, y)==' ') {
						for (int i=y; i>2; i--) {
							Cell->Set(x, i, Cell->Get(x, i-1));
						}
						Cell->Set(x, 2, ' ');
					}
				}
			}
		}
		
		if (State==1) {
			Time++;
			if (Time==30) {
				char c=Cell->Get(1, ys-2);
				int x, y;
				for (x=2; Cell->Get(x, ys-2)==c; x++) ;
				if (x<1+PUSHED_AND_COLLECTED_BLOCK_ERASE) {
					for (y=2; y<ys-4; y++) {
						for (x=1; x<xs-1; x++) {
							Cell->Set(x, y, Cell->Get(x, y+1));
						}
					}
					for (x=1; x<xs-1; x++) {
						Cell->Set(x, ys-4, Cell->Get(x, ys-2));
					}
				}
				for (x=1; x<xs-1; x++) {
					Cell->Set(x, ys-2, ' ');
				}
				State=0;
			}
		}
		return true;
	}
	
	virtual void Draw() {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();
		float 
			sw=Game->GetGraphics()->GetWidth()/xs,
			sh=Game->GetGraphics()->GetHeight()/ys;
		for (int y=0; y<ys; y++) {
			for (int x=0; x<xs; x++) {
				char c=Cell->Get(x, y);
				int texture=TEX_VOID;
				if (c=='=') {
					texture=TEX_DROP_FLOOR;
				} else
				if (c!=' ') {
					texture=TEX_BALL0+c-'0';
				}
				Game->Texture[texture]->Draw(
					x*sw, y*sh, sw, sh, 
					0, 0, 1, 1, COL_BLACK);
			}
		}
		Game->Texture[TEX_MAN]->Draw(
			CX*sw, CY*sh, sw, sh, 0, 0, 1, 1, COL_BLACK);
	}
};

//==============================================================
// �������� ������ �޾Ƽ� �ױ�

#define CAUGHT_AND_PILED_BLOCK_COUNT 5
#define CAUGHT_AND_PILED_BLOCK_ERASE 3

// ��������
class CCaughtAndPiledBlockStage : public CStage {
public:
	CCell* Cell;
	int CX, CY, State, Time, DropTime;
	char Block;
	bool PrevLever, PrevButton;

	CCaughtAndPiledBlockStage() : CStage(L"CAUGHT AND PILED BLOCK") {
		Cell=new CCell();
	}

	virtual ~CCaughtAndPiledBlockStage() {
		delete Cell;
	}

	virtual void Init() {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();
		Cell->Init(
			"                "
			"================"
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"=              ="
			"================"
		);
		PrevLever=false;
		CX=xs/2;
		CY=7;
		Block=' ';
		DropTime=0;
		State=0;
	}

	virtual bool Move(const CInputState* is) {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();

		if (State==0) {
			if (!PrevLever) {
				if (is->Left && CX>1) CX--; else
				if (is->Right && CX<xs-2) CX++;
			}
			PrevLever=is->Left||is->Right;

			if (!PrevButton && is->Button[0] && Block!=' ') {
				if (Cell->Get(CX, ys-4)==' ') {
					Cell->Set(CX, ys-4, Block);
					Block=' ';
					State=1;
				}
			}
			PrevButton=is->Button[0];
			
			DropTime++;
			if (DropTime==60) {
				DropTime=0;
				if (Block==' ' && Cell->Get(CX, CY-1)!=' ') {
					Block=Cell->Get(CX, CY-1);
				}
				for (int y=CY-1; y>2; y--) {
					for (int x=1; x<xs-1; x++) {
						Cell->Set(x, y, Cell->Get(x, y-1));
					}
				}
				for (int x=1; x<xs-1; x++) {
					Cell->Set(x, 2, ' ');
				}
				Cell->Set(Rand.Int31()%(xs-2)+1, 2, '0'+Rand.Int31()%CAUGHT_AND_PILED_BLOCK_COUNT);
			}
		}
		
		if (State==1) {
			for (int x=1; x<xs-1; x++) {
				for (int y=CY+1; y<ys-1; y++) {
					if (Cell->Get(x, y)==' ') {
						for (int i=y; i>CY+1; i--) {
							Cell->Set(x, i, Cell->Get(x, i-1));
						}
						Cell->Set(x, CY+1, ' ');
					}
				}
			}

			State=0;
			for (int y=CY+1; y<ys-1; y++) {
				for (int x=1; x<xs-1; x++) {
					char c=Cell->Get(x, y)&0x7f;
					if (c==' ') continue;
					static const int
						vx[]={0, 1, -1, 1},
						vy[]={1, 0, 1, 1};
					for (int v=0; v<4; v++) {
						int count=0;
						for (
							int i=x, j=y;
							1<=i && i<xs-1 && CY+1<=j && j<ys-1; 
							i+=vx[v], j+=vy[v], count++
						) {
							if (c!=(Cell->Get(i, j)&0x7f)) break;
						}
						if (count>=CAUGHT_AND_PILED_BLOCK_ERASE) {
							for (int i=x, j=y, k=0; k<count; i+=vx[v], j+=vy[v], k++) {
								Cell->Set(i, j, Cell->Get(i, j)|0x80);
							}
							Time=0;
							State=2;
						}
					}
				}
			}
		}
		
		if (State==2) {
			Time++;
			if (Time==30) {
				for (int y=CY+1; y<ys-1; y++) {
					for (int x=1; x<xs-1; x++) {
						if (Cell->Get(x, y)&0x80) {
							Cell->Set(x, y, ' ');
						}
					}
				}
				State=1;
			}
		}

		return true;
	}
	
	virtual void Draw() {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize();
		float 
			sw=Game->GetGraphics()->GetWidth()/xs,
			sh=Game->GetGraphics()->GetHeight()/ys;
		Game->Texture[TEX_FILL]->Draw(
			sw, (ys-4)*sh, sw*(xs-2), sh*3, 
			0, 0, 1, 1, COL_LGRAY);
		for (int y=0; y<ys; y++) {
			for (int x=0; x<xs; x++) {
				char c=Cell->Get(x, y);
				int texture=TEX_VOID;
				if (c=='=') {
					texture=TEX_DROP_FLOOR;
				} else
				if (c!=' ') {
					texture=TEX_BALL0+(c&0x3f)-'0';
				}
				if (c&0x80) {
					float f=(float)Time/30;
					Game->Texture[texture]->Draw(
						x*sw, y*sh, sw, sh, 
						0, 0, 1, 1, D3DXCOLOR(f, f, f, 1));			
				} else {
					Game->Texture[texture]->Draw(
						x*sw, y*sh, sw, sh, 
						0, 0, 1, 1, COL_BLACK);
				}
			}
		}
		Game->Texture[TEX_MAN]->Draw(
			CX*sw, CY*sh, sw, sh, 0, 0, 1, 1, COL_BLACK);
		if (Block!=' ') {
			Game->Texture[TEX_BALL0+Block-'0']->Draw(
				CX*sw, (CY-1)*sh, sw, sh, 0, 0, 1, 1, COL_LGRAY);
		}
	}
};

//==============================================================
// �ٴڿ� ǥ���Ͽ� ���� ���ֱ�

// ��������
class CMarkedAndSunkBlockStage : public CStage {
public:
	CCell3D* Cell;
	int CX, CY, CZ, State, Time, DropTime;
	bool PrevLever, PrevButton;

	CMarkedAndSunkBlockStage() : CStage(L"MARKED AND SUNK BLOCK") {
		Cell=new CCell3D(5, 2, 12);
	}
	virtual ~CMarkedAndSunkBlockStage() {
		delete Cell;
	}
	virtual void Init() {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize(), zs=Cell->GetZSize();
		for (int z=0; z<zs; z++) {
			for (int x=0; x<xs; x++) {
				Cell->Set(x, 1, z, ' ');
				Cell->Set(x, 0, z, '=');
			}
		}
		CX=xs/2;
		CY=1;
		CZ=0;
		PrevLever=true;
		PrevButton=true;
		DropTime=0;
		State=0;
	}
	virtual bool Move(const CInputState* is) {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize(), zs=Cell->GetZSize();

		if (State==0) {
			if (!PrevLever) {
				if (is->Left && CX>0) CX--;
				if (is->Right && CX<xs-1) CX++;
				if (is->Up && CZ<zs-1) CZ++;
				if (is->Down && CZ>0) CZ--;
			}
			PrevLever=is->Left||is->Right||is->Up||is->Down;
			
			if (!PrevButton) {
				if (is->Button[0]) {
					switch (Cell->Get(CX, 0, CZ)) {
						case '=': Cell->Set(CX, 0, CZ, '-'); break;
						case '-': Cell->Set(CX, 0, CZ, '='); break;
					}
				} else
				if (is->Button[1]) {
					for (int z=0; z<zs; z++) {
						for (int x=0; x<xs; x++) {
							if (Cell->Get(x, 1, z)=='#' && Cell->Get(x, 0, z)=='-') {
								Cell->Set(x, 1, z, '+');
								Time=0;
								State=1;
							}
						}
					}
				}
			}
			PrevButton=is->Button[0]||is->Button[1];
			
			DropTime++;
			if (DropTime==60) {
				DropTime=0;
				for (int z=0; z<zs-1; z++) {
					for (int x=0; x<xs; x++) {
						Cell->Set(x, 1, z, Cell->Get(x, 1, z+1));
					}
				}
				for (int x=0; x<xs; x++) {
					Cell->Set(x, 1, zs-1, ' ');
				}
				Cell->Set(Rand.Int31()%xs, 1, zs-1, '#');
			}
		}
		
		if (State==1) {
			Time++;
			if (Time==30) {
				for (int z=0; z<zs; z++) {
					for (int x=0; x<xs; x++) {
						if (Cell->Get(x, 1, z)=='+') {
							Cell->Set(x, 1, z, ' ');
						}
					}
				}
				State=0;
			}
		}
		
		return true;
	}
	virtual void Draw() {
		int xs=Cell->GetXSize(), ys=Cell->GetYSize(), zs=Cell->GetZSize();

		IDirect3DDevice9* device=Game->GetGraphics()->GetDevice();
		D3DXMATRIX mat_view, mat_view_old;
		D3DXVECTOR3 vec_from=D3DXVECTOR3(8, 10, -6);
		D3DXVECTOR3 vec_lookat=D3DXVECTOR3(xs*0.5f, ys*0.5f, zs*0.5f-2);
		D3DXVECTOR3 vec_up=D3DXVECTOR3(0, 1, 0);
		D3DXMatrixLookAtLH(&mat_view, &vec_from, &vec_lookat, &vec_up);
		device->GetTransform(D3DTS_VIEW, &mat_view_old);
		device->SetTransform(D3DTS_VIEW, &mat_view);
		
		for (int z=zs-1; z>=0; z--) {
			for (int y=0; y<ys; y++) {
				for (int x=0; x<xs; x++) {
					if (x==CX && y==CY && z==CZ) {
						Game->Mesh[MESH_BALL_BLACK]->Draw(CX, CY, CZ, 1, 1, 1, 0, 0, 0, TO_NONE, 1, 0);
					}
					switch (Cell->Get(x, y, z)) {
						case '#':
							Game->Mesh[MESH_CUBE_GRAY]->Draw(x, y, z, 1, 1, 1, 0, 0, 0, TO_NONE, 0.5f, 0);
							break;
						case '+':
							Game->Mesh[MESH_CUBE_GRAY]->Draw(x, y-(float)Time/30, z, 1, 1, 1, 0, 0, 0, TO_NONE, 0.5f, 0);
							break;
						case '-':
							Game->Mesh[MESH_CUBE_GRAY]->Draw(x, y, z, 1, 1, 1, 0, 0, 0, TO_NONE, 1, 0);
							break;
						case '=':
							Game->Mesh[MESH_CUBE_WHITE]->Draw(x, y, z, 1, 1, 1, 0, 0, 0, TO_NONE, 1, 0);
							break;
					}
				}
			}
		}

		device->SetTransform(D3DTS_VIEW, &mat_view_old);
	}
};

