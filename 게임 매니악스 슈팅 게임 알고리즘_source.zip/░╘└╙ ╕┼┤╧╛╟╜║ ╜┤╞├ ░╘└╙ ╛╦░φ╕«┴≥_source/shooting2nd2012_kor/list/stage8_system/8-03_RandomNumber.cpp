// 난수의 시드(씨앗)
typedef unsigned int ulong;
static ulong seed=1;

// 시드의 초기화
void srand(ulong s) {
	seed=s;
}

// 난수의 생성
ulong rand() {
	seed=seed*48828125UL+1;
	return seed;
}

