void MoveUp();
void MoveDown();
void MoveLeft();
void MoveRight();
void Shot();
void Laser();

// 스틱과 버튼의 입력값을 나타내는 상수:
// 각 입력을 1비트로 나타냄.
enum {
	UP=1, DOWN=2, LEFT=4, RIGHT=8,
	BUTTON1=16, BUTTON2=32
} INPUT;

// 리플레이 데이터를 저장하느 구조체:
// 스틱과 버튼의 입력값을 저장함.スティックとボタンの入力を保存する。
#define MAX_TIME 10000
typedef struct {
	char Input[MAX_TIME];
} REPLAY_DATA;

// 메인 캐릭터를 이동시킴
void MoveMyShip(
	char input,                // 스틱과 버튼의 입력값
	bool is_replay,            // 리플레이중인지를 나타내는 플래그
	REPLAY_DATA* replay_data,  // 리플레이 데이터
	int& time                  // 타이며
) {
	// 리플레이 처리:
	// 리플레이중이면 입력값을 리플레이 데이터에서 읽음.
	// 리플레이중이 아니면 리플레이 데이터에 입력값을 저장함.
	if (is_replay) {
		input=replay_data->Input[time];
	} else {
		replay_data->Input[time]=input;
	}
	
	// 타이머를 진행시킴
	time++;

	// 입력에 따라 메인 캐릭터를 이동시킴:
	// 이동이나 사격의 구체적인 처리는
	// MoveUp, MoveDown, MoveLeft, MoveRight,
	// Shot, Laser 함수에서 각각 수행하기로 함.
	if (input&UP   ) MoveUp();
	if (input&DOWN ) MoveDown();
	if (input&LEFT ) MoveLeft();
	if (input&RIGHT) MoveRight();
	if (input&BUTTON1) Shot();
	if (input&BUTTON2) Laser();
}

