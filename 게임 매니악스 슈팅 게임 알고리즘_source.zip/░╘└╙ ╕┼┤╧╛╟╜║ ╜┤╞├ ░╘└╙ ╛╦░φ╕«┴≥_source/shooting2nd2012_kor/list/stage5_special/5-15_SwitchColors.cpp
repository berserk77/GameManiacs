void Shot(bool color);
bool HitBullet(int id);
void DeleteBullet(int id);
void Miss();

void SwitchColors(
	bool color_button,   // 색깔 바꾸기 버튼의 상태
	bool shot_button,    // 샷 버튼의 상태
	int num_bullet,      // 탄의 갯수
	bool bullet_color[]  // 탄의 색깔
) {
	static bool prev_col_button=false;  // 색깔 바꾸기 버튼의 이전 상태
	static bool color=true;             // 메인 캐릭터의 색
	static int energy=0;                // 에너지
	
	// 색깔을 바꾸기
	if (!prev_col_button && color_button) color=~color;
	prev_col_button=color_button;
	
	// 샷을 발사하기:
	// 메인 캐릭터와 같은 색의 샷을 발사.
	// 구체적인 처리는 Shot 함수에서 수행하기로 함.
	if (shot_button) Shot(color);
	
	// 탄과 접촉 판정:
	// 구체적인 처리는 HitBullet 함수에서 수행하기로 함.
	for (int i=0; i<num_bullet; i++) {
		if (HitBullet(i)) {
			
			// 같은 색이라면 흡수:
			// 탄을 제거하고 에너지를 늘림.
			// 탄을 제거하는 구체적인 처리는 DeleteBullet 함수에서 수행하기로 함.
			if (color==bullet_color[i]) {
				DeleteBullet(i);
				energy++;
			}
			
			// 다른 색이라면 피해를 입음:
			// 피해를 입는 구체적인 처리는 Miss 함수에서 수행하기로 함.
			else {
				Miss();
			}
		}
	}
}

