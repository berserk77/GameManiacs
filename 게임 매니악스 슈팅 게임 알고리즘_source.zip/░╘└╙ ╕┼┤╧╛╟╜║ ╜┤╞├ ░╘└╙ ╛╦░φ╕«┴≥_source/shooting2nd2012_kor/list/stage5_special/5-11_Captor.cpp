bool CaptureAttack();
void NormalAttack();
bool Destroyed();
void ReturnMyShip();
void Delete();

// 적기의 상태:
// 보통 상태, 포획 상태
typedef enum {
	NORMAL, CAPTURED
} CAPTOR_STATE;

// 메인 캐릭터를 포획가능한 적기의 움직임
void Captor(
	bool capture  // 포획 공격을 할 지를 나타내는 플래그
) {
	static int state=NORMAL;  // 적기의 상태
	
	// 상태에 따라 분기
	switch (state) {
		
		// 보통 상태:
		// 보통 공격 혹은 포획 공격을 수행함.
		// 포획 공격이 성공했다면 포획상태로 이동함.
		// 공격의 구체적인 처리는 CaptureAttack,
		// NormalAttack 함수에서 각각 수행하기로 함.
		case NORMAL:
			if (capture) {
				if (CaptureAttack()) state=CAPTURED;
			} else {
				NormalAttack();
			}
			break;
		
		// 포획 상태:
		// 통상 공격을 수행함.
		// 파괴되었다면 메인 캐릭터를 되돌려 준 후에 제거함.
		// 판정 등의 구체적인 처리는 Destroyed,
		// ReturnMyShip, Delete 함수에서 각각 수행하기로 함.
		case CAPTURED:
			NormalAttack();
			if (Destroyed()) {
				ReturnMyShip();
				Delete();
			}
			break;
	}
}

