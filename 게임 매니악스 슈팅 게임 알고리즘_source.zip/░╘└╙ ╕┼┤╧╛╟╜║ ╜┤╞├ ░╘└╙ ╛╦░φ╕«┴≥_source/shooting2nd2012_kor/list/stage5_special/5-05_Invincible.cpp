void DamageEnemy(int id);
void DeleteBullet(int id);
void Miss();

void Invincible(
	bool invincible,           // 무적상태라면 true
	float x0, float y0,        // 메인 캐릭터의 좌상좌표
	float x1, float y1,        // 메인 캐릭터의 우하좌표
	float ex0[], float ey0[],  // 적기의 좌상좌표
	float ex1[], float ey1[],  // 적기의 좌상좌표
	int num_enemy,             // 적기의 갯수
	float bx0[], float by0[],  // 탄의 좌상좌표
	float bx1[], float by1[],  // 탄의 좌상좌표
	int num_bullet             // 탄의 갯수
) {
	// 적기와 접촉 판정:
	// 적기와 부딪혔을 경우, 무적상태라면 적기에게 피해를 입히고
	// 통상 상태라면 피해를 받음.
	// 피해를 주는 처리와 받는 처리는
	// DamageEnemy, Missの 함수에서 수행하기로 함.
	for (int i=0; i<num_enemy; i++) {
		if (ex0[i]<x1 && x0<ex1[i] && 
			ey0[i]<y1 && y0<ey1[i]) {
			if (invincible) DamageEnemy(i); else Miss();
		}
	}
	
	// 탄과 접촉 판정:
	// 탄과 부딪혔을 경우, 무적상태라면 탄을 제거하고
	// 보통 상태라면 피해를 받음.
	// 탄을 제거하느 처리와 피해를 받는 처리는
	// DeleteBullet, Missの 함수에서 수행하기로 함.
	for (int i=0; i<num_bullet; i++) {
		if (bx0[i]<x1 && x0<bx1[i] && 
			by0[i]<y1 && y0<by1[i]) {
			if (invincible) DeleteBullet(i); else Miss();
		}
	}
}
