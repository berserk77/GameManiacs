#include <math.h>

void DeleteBullet(int id);
void Shot(float x, float y, float vx, float vy);

void ReflectBullet(
	float fx0, float fy0,    // 반사막의 좌상좌표
	float fx1, float fy1,    // 반사막의 우하좌표
	int num_bullet,          // 탄의 갯수
	float x0[], float y0[],  // 탄의 좌상좌표
	float x1[], float y1[],  // 탄의 우하좌표
	float x[], float y[],    // 탄의 중심좌표
	float ex[], float ey[],  // 탄을 쏜 적기의 중심좌표
	float speed              // 샷의 속도
) {
	// 모든 탄에 대하여 처리를 해 줌
	for (int i=0; i<num_bullet; i++) {
	
		// 탄과 반사막의 접촉 판정:
		// 탄이 반사막에 접촉했다면
		// 탄을 제거하고 그 자리에서 적기를 향해 날아가는 샷을 발사함.
		if (fx0<x1[i] && x0[i]<fx1 && 
			fy0<y1[i] && y0[i]<fy1) {

			// 탄의 제거:
			// 구체적인 처리는 DeleteBullet 함수에서 수행하기로 함.
			DeleteBullet(i);
			
			// 샷의 발사:
			// 적기를 향하는 샷을 발사.
			// 구체적인 처리는 Shot 함수에서 수행하기로 함.
			float vx=ex[i]-x[i], vy=ey[i]-y[i];
			if (vx!=0 || vy!=0) {
				float d=sqrt(vx*vx+vy*vy);
				vx*=speed/d;
				vy*=speed/d;
				Shot(x[i], y[i], vx, vy);
			}
		}
	}
}

