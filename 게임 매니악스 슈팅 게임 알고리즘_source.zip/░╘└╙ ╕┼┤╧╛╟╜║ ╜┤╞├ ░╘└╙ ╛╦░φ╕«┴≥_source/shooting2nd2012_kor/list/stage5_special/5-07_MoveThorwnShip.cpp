void MoveThrownShip(
	float& x0, float& y0,  // 기체의 좌상좌표
	float& x1, float& y1,  // 기체의 우하좌표
	float& vx, float& vy,  // 기체의 속도 벡터
	float sx0, float sy0,  // 이동가능 범위(화면 둘레)의 좌상좌표
	float sx1, float sy1   // 이동가능 범위(화면 둘레)의 우하좌표
) {
	// 떠돌아 다니는 움직임을 위한 처리:
	// 화면 둘레의 상하좌우에서 도달하면
	// 이동 속도를 역으로 해 줌.
	if (x0+vx<sx0 || sx1<=x1+vx) vx=-vx;
	if (y0+vy<sy0 || sy1<=y1+vy) vy=-vy;
	
	// 기체를 이동시킴.
	x0+=vx; x1+=vx;
	y0+=vy; y1+=vy;
}

