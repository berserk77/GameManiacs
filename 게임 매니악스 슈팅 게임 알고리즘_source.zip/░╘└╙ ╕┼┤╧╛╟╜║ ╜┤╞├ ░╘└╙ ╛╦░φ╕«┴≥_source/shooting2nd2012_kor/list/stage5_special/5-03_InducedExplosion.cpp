void DestroyEnemy(int id);
void CreateExplosion(float x, float y);

void InducedExplosion(
	float ex0[], float ey0[],  // 적기의 좌상좌표
	float ex1[], float ey1[],  // 적기의 우하좌표
	int num_enemy,             // 적기의 갯수
	float x0[], float y0[],    // 후폭풍의 좌상좌표
	float x1[], float y1[],    // 후폭풍의 우하좌표
	int num_explosion          // 후폭풍의 갯수
) {
	// 적기와 후폭풍의 접촉 판정 처리:
	// 모든 적기와 후폭풍간에 접촉 판정 처리를 수행하고
	// 적기가 폭풍에 닿았다면 파괴시킴.
	// 그리고, 적기가 사라진 자리에 새로운 후폭풍을 생성함.
	// 파괴와 생성의 구체적인 처리는
	// DestroyEnemy, CreateExplosion 함수에서 수행하기로 함.
	for (int i=0; i<num_enemy; i++) {
		for (int j=0; j<num_explosion; j++) {
			if (ex0[i]<x1[j] && x0[j]<ex1[i] && 
				ey0[i]<y1[j] && y0[j]<ey1[i]) {
				DestroyEnemy(i);
				CreateExplosion(ex0[i], ey0[i]);
			}
		}
	}
}
