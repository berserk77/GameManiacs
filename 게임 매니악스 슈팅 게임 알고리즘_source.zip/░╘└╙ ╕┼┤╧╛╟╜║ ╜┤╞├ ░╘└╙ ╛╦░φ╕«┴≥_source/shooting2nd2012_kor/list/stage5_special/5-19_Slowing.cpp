void MoveEnemy();
void MoveBullet();

void Slowing(
	int& gauge,  // 슬로우 상태로 전환하기 위해 필요한 게이지
	bool button  // 슬로우 버튼을 눌렀는지 나타내는 플래그
) {
	// 타이머:
	// 슬로우 상태일 때 행동회수를 조절하기 위해 사용함.
	static int time=1;

	// 적기와 탄을 이동시킴:
	// 보통 상태일 때는 매번 이동시키고
	// 슬로우 상태일 때는 2번에 1번만 움직임.
	// 이동의 구체적인 처리는
	// MoveEnemy, MoveBullet 함수에서 수행하기로 함.
	if (!button || (gauge>0 && time==0)) {
		MoveEnemy();
		MoveBullet();
	}
	
	// 페널티:
	// 게이지가 0인데 슬로우 버튼을 눌렀다면
	// 페널티로서 탄을 1번 더 이동시킴.
	// 결과적으로 탄이 2배의 속도로 움직이게 됨.
	if (button && gauge==0) {
		MoveBullet();
	}

	// 타이머의 갱신
	if (time>0) time--; else time=1;
}

