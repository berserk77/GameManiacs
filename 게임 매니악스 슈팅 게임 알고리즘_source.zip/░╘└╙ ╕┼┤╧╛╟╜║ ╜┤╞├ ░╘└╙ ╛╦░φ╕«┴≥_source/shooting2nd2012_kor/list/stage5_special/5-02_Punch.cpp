void DamageEnemy(int id);
void DrawPunch();

// 근접공격 처리
void Punch(
	bool button,               // 버튼의 상태 (눌렸으면 true)
	float px0, float py0,      // 근접공격의 좌상좌표
	float px1, float py1,      // 근접공격의 우하좌표
	float ex0[], float ey0[],  // 적기의 좌상좌표
	float ex1[], float ey1[],  // 적기의 우하좌표
	int num_enemy              // 적기의 갯수
) {
	static bool punching=false;  // 근접공격중인지를 나타내는 플래그
	static int punch_time;       // 근접공격을 실시할 시간
	
	// 근접공격 개시:
	// 근접공격중이 아닌 상태에서 버튼이 눌렸다면
	// 근접공격을 실시함.
	if (!punching && button) {
		punching=true;
		punch_time=30;
	}
	
	// 근접공격중의 처리
	if (punching) {

		// 적기와의 접촉 판정:
		// 피해를 입히는 구체적인 처리는
		// DamageEnemy 함수에서 수행하기로 함.
		for (int i=0; i<num_enemy; i++) {
			if (ex0[i]<px1 && px0<ex1[i] && 
				ey0[i]<py1 && py0<ey1[i]) {
				DamageEnemy(i);
			}
		}

		// 근접공격 표시:
		// 표시의 구체적인 처리는 DrawPunch 함수에서 수행하기로 함.
		DrawPunch();

		// 근접공격을 계속할 지 종료할 지 판단하기:
		// 지속시간을 지났다면 그만두기.
		if (punch_time==0) punching=false; else punch_time--;
	}
}

