void GrazeBullet(
	float gx0, float gy0,    // 스침 판정의 좌상좌표
	float gx1, float gy1,    // 스침 판정의 우하좌표
	int num_bullet,          // 탄의 갯수
	float x0[], float y0[],  // 탄의 접촉 판정 영역의 좌상좌표
	float x1[], float y1[],  // 탄의 접촉 판정 영역의 우하좌표
	bool grazing[],          // 탄이 스쳤는지를 나타내는 플래그
	int time[],              // 스친 시간
	int& power               // 메인 캐릭터의 파워
	                         // (경험치, 득점배율등)
) {
	// 모든 탄에 대하여 처리
	for (int i=0; i<num_bullet; i++) {

		// 보통 상태:
		// 접촉 판정을 실시하여 탄이 메인 캐릭터에 스쳤다면
		// 스침 상태로 이동.
		// 스침 상태의 남은 시간을 설정하고 메인 캐릭터으 파워를 늘림.
		if (!grazing[i]) {
			if (gx0<x1[i] && x0[i]<gx1 && 
				gy0<y1[i] && y0[i]<gy1) {
				grazing[i]=true;
				time[i]=20;
				power++;
			}
		}
		
		// 스침 상태:
		// 스침 상태의 남은 시간을 줄여주고
		// 시간이 0이 되었다면 보통 상태로 돌아감.
		// 이 처리를 제거하면 탄에 한 번 밖에 스칠 수 없게 됨.
		else {
			if (time[i]==0) grazing[i]=false; else time[i]--;
		}
	}
}

