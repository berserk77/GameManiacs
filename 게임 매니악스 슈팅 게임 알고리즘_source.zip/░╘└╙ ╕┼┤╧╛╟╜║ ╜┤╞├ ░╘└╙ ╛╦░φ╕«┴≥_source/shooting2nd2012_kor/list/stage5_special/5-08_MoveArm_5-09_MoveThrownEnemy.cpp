void DeleteEnemy(int id);
void CreateExplosion(float x, float y);

// 집게의 상태:
// 대기 상태, 늘어나고 있는 상태, 완전히 늘어난 상태, 줄어들고 있는 상태
typedef enum {
	READY, EXTENDING, EXTENDED, SHRINKING
} STATE_TYPE;

// 집게의 움직임
void MoveArm(
	bool button  // 집게 사용 버튼의 상태
) {
	static STATE_TYPE state=READY;  // 집게의 상태
	static int length;              // 집게의 길이
	static int max_length=20;       // 집게의 최대 길이
	static int time;                // 일정 시간 대기용
	
	// 집게의 상태에 따라 분기
	switch (state) {
		
		// 대기 상태:
		// 버튼이 눌렸다면 집게를 늘림.
		case READY:
			if (button) {
				state=EXTENDING;
				length=0;
			}
			break;
		
		// 늘어나고 있는 상태:
		// 집게를 늘리고 최대 길이에 도달했다면
		// 완전히 늘어난 상태로 이동.
		case EXTENDING:
			if (length<max_length) {
				length++;
			} else {
				state=EXTENDED;
				time=10;
			}
			break;
		
		// 완전히 늘어난 상태:
		// 일정 시간 경과후 원래 길이로 되돌림.
		case EXTENDED:
			if (time>0) {
				time--;
			} else {
				state=SHRINKING;
			}
			break;
		
		// 줄어들고 있는 상태:
		// 길이가 0이 되었다면 대기 상태로 되돌림.
		case SHRINKING:
			if (length>0) {
				length--;
			} else {
				state=READY;
			}
			break;
	}
}

void MoveThrownEnemy(
	float& x0, float& y0,      // 던져진 적기의 좌상좌표
	float& x1, float& y1,      // 던져진 적기의 우하좌표
	float vx, float vy,        // 던져진 적기의 속도 벡터
	float ex0[], float ey0[],  // 다른 적기의 좌상좌표
	float ex1[], float ey1[],  // 다른 적기의 우하좌표
	int num_enemy              // 다른 적기의 갯수
) {
	// 적기와 접촉 판정:
	// 던져진 적기와 다른 적기간에 
	// 접촉 판정 처리를 수행.
	// 충돌하였다면 던져진 적기를 제거하고
	// 대신 후폭풍을 생성함.
	// 던져진 적기 제거와 후폭풍 생성의 구체적인 처리는
	// DeleteEnemy, CreateExplosion 함수에서 각각 수행하기로 함.
	int i;
	for (i=0; i<num_enemy; i++) {
		if (ex0[i]<x1 && x0<ex1[i] && 
			ey0[i]<y1 && y0<ey1[i]) {
			DeleteEnemy(i);
			CreateExplosion(x0, y0);
		}
	}
	
	// 다른 적기에게 부딪히지 않았을 경우:
	// 던져진 적기를 이동시킴.
	if (i==num_enemy) {
		x0+=vx; y0+=vy;
		x1+=vx; y1+=vy;
	}
}


