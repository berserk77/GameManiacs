void NormalAttack();
void SpecialAttack();

void ItemSpecialAttack(
	float x0, float y0,        // 메인 캐릭터의 좌상좌표
	float x1, float y1,        // 메인 캐릭터의 우하좌표!
	float ix0[], float iy0[],  // 아이템의 좌상좌표
	float ix1[], float iy1[],  // 아이템의 좌상좌표
	int num_item               // 아이템의 数
) {
	static bool special=false;  // 지금 상태가 특수상태라면 true
	static int time;            // 특수공격의 남은 시간
	
	// 보통 상태일 때
	if (!special) {

		// 보통 공격을 수행함:
		// 구체적인 처리는 NormalAttack 함수에서 수행하기로 함.
		NormalAttack();
		
		// 아이템을 얻었는 지를 판정하기:
		// 아이템을 얻었다면 특수상태로 이동하여 남은 시간을 설정함.
		for (int i=0; i<num_item; i++) {
			if (ix0[i]<x1 && x0<ix1[i] && 
				iy0[i]<y1 && y0<iy1[i]) {
				special=true;
				time=300;
			}
		}
	}
	
	// 특수 상태일 때
	else {
		
		// 특수 공격을 수행함:
		// 구체적인 처리는 SpecialAttack 함수에서 수행하기로 함.
		SpecialAttack();
		
		// 시간이 경과했는지 판정:
		// 남은 시간이 없어지면 보통 상태로 되돌림.
		if (time==0) special=false; else time--;
	}
}

