#include <math.h>

void Shot(float x, float y, float vx, float vy);

void MoveSight2(
	float& x, float& y,       // 메인 캐릭터의 좌표
	float speed,              // 메인 캐릭터의 속도
	bool up1, bool down1,     // 메인 캐릭터용 스틱 입력1(상하)
	bool left1, bool right1,  // 메인 캐릭터용 스틱 입력1(좌우)
	float& sx, float& sy,     // 조준의 좌표
	float sight_speed,        // 조준의 속도
	bool up2, bool down2,     // 조준 입력용 스틱 입력2(상하)
	bool left2, bool right2,  // 조준 입력용 스틱 입력2(좌우)
	bool button,              // 샷 버튼의 입력상태
	float shot_speed          // 샷의 속도
) {
	// 메인 캐릭터를 이동
	if (up1   ) y-=speed;
	if (down1 ) y+=speed;
	if (left1 ) x-=speed;
	if (right1) x+=speed;

	// 조준을 이동
	if (up2   ) sy-=sight_speed;
	if (down2 ) sy+=sight_speed;
	if (left2 ) sx-=sight_speed;
	if (right2) sx+=sight_speed;

	// 샷을 발사:
	// 샷 버튼이 눌렸다면
	// 메인 캐릭터에서 조준을 향해 샷을 발사.
	// 발사의 구체적인 처리는 Shot 함수에서 수행하기로 함.
	if (button) {
		float vx=sx-x, vy=sy-y;
		if (vx!=0 || vy!=0) {
			float d=sqrt(vx*vx+vy*vy);
			vx*=shot_speed/d;
			vy*=shot_speed/d;
			Shot(x, y, vx, vy);
		}
	}
}

