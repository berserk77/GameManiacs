#include <math.h>

void SpecialShot(float x, float y, float vx, float vy);

void ReinforcedShot2(
	float x, float y,    // 메인 캐릭터의 좌표
	float cx, float cy,  // 아군 캐릭터의 좌표
	float speed          // 샷의 속도
) {
	// 샷의 속도를 구하기
	float vx=x-cx, vy=y-cy;
	float d=sqrt(vx*vx+vy*vy);
	vx*=speed/d;
	vy*=speed/d;

	// 샷을 발사하기:
	// 구체적인 처리는 SpecialShot 함수에서 수행하기로 함.
	SpecialShot(x, y, vx, vy);
}

