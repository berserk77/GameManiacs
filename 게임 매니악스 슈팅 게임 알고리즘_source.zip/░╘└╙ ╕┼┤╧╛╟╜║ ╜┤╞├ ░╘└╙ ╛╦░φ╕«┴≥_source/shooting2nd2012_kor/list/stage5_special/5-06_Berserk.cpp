void NormalAttack();
void SpecialAttack();
bool HitShot(int id);
bool HitEnemy(int id);
bool HitBullet(int id);
void DeleteShot(int id);
void Miss();
void DamageEnemy(int id);
void DeleteBullet(int id);

// 메인 캐릭터의 상태(보통 상태, 버서크 상태, 약한 상태)
typedef enum {
	NORMAL, BERSERK, WEAK
} STATE_TYPE;

// 버서크 상태의 처리
void Berserk(
	int num_shot,   // 아군의 샷의 수
	int num_enemy,  // 적기의 갯수
	int num_bullet  // 탄(적기의 탄)의 갯수
) {
	static STATE_TYPE state=NORMAL;  // 메인 캐릭터의 상태(처음에는 보통 상태)
	static int energy=0;             // 에너지
	static int berserk_energy=100;   // 버서크 상태가 되기 위해
	                                 // 필요한 에너지
	static int time;                 // 버서크 효과의 잔여시간
	
	// 메인 캐릭터의 상태에 따라 분기
	switch (state) {
		
		// 보통 상태
		case NORMAL:

			// 보통 공격:
			// 구체적인 처리는 NormalAttack 함수에서 수행하기로 함.
			NormalAttack();

			// 탄이나 적기와 접촉 판정:
			// 부딪히면 피해를 받음.
			// 판정이나 결과의 구체적인 처리는 HitEnemy,
			// HitBullet, Miss 함수에서 각각 수행하기로 함.
			for (int i=0; i<num_enemy; i++)
				if (HitEnemy(i)) Miss();
			for (int i=0; i<num_bullet; i++)
				if (HitBullet(i)) Miss();

			// 아군 캐릭터가 쏜 샷과 접촉 판정:
			// 에너지를 모음.
			// 판정이나 결과의 구체적인 처리는 HitShot,
			// DeleteShot 함수에서 각각 수행하기로 함.
			for (int i=0; i<num_shot; i++) {
				if (HitShot(i)) {
					energy++;
					DeleteShot(i);
				}
			}

			// 에너지 양 판단:
			// 에너지가 충분히 모였으면
			// 버서크 상태로 이동함.
			// 에너지는 시간이 지남에 따라 저절로 감소됨.
			if (energy>=berserk_energy) {
				state=BERSERK;
				time=300;
			} else {
				energy--;
			}

			break;
		
		// 버서크 상태
		case BERSERK:

			// 특수 공격:
			// 구체적인 처리는 SpecialAttack 함수에서 수행하기로 함.
			SpecialAttack();

			// 적기나 탄과 접촉 판정:
			// 적기에는 피해를 주고 탄은 제거함.
			// 결과의 구체적인 처리는 DamageEnemy,
			// DeleteBullet 함수에서 각각 수행하기로 함.
			for (int i=0; i<num_enemy; i++)
				if (HitEnemy(i)) DamageEnemy(i);
			for (int i=0; i<num_bullet; i++)
				if (HitBullet(i)) DeleteBullet(i);
			
			// 남은 시간이 다 되었다면 약한 상태로 이동함.
			time--;
			if (time<=0) {
				state=WEAK;
				time=200;
			}
			
			break;
			
		// 약한 상태
		case WEAK:
			
			// 적기나 탄과 접촉 판정:
			// 맞으면 피해를 받음.
			for (int i=0; i<num_enemy; i++)
				if (HitEnemy(i)) Miss();
			for (int i=0; i<num_bullet; i++)
				if (HitBullet(i)) Miss();

			// 남은 시간이 다 되었다면 보통 상태로 이동함.
			time--;
			if (time<=0) {
				state=NORMAL;
				energy=0;
			}
			
			break;
	}
}

