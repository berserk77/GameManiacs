void DamageEnemy(int id);
void DeleteBullet(int id);
void DeleteCapturedEnemy();
void Shot();

void CapturedEnemy(
	float& x0, float& y0,      // 아군이 된 적기의 좌상좌표
	float& x1, float& y1,      // 아군이 된 적기의 우하좌표
	float ex0[], float ey0[],  // 다른 적기의 좌상좌표
	float ex1[], float ey1[],  // 다른 적기의 우하좌표
	int num_enemy,		   // 다른 적기의 갯수
	float bx0[], float by0[],  // 탄의 좌상좌표
	float bx1[], float by1[],  // 탄의 우하좌표
	int num_bullet,            // 탄의 갯수
	bool button                // 샷 버튼의 상태
) {
	static int damage;         // 현재의 피해정도
	static int max_damage=40;  // 피해의 한계치

	// 적기와 접촉 판정:
	// 적기와 충돌햇다면 적기에게 피해를 주고
	// 자신도 피해를 입음.
	// 피해를 주고 받는 구체적인 처리는
	// DamageEnemy 함수에서 수행하기로 함.
	for (int i=0; i<num_enemy; i++) {
		if (ex0[i]<x1 && x0<ex1[i] && 
			ey0[i]<y1 && y0<ey1[i]) {
			DamageEnemy(i);
			damage++;
		}
	}
	
	// 탄과 접촉 판정:
	// 탄과 충돌했다면 탄을 제거하고
	// 자신도 피해를 입음.
	// 탄을 제거하는 구체적인 처리는 ，
	// DeleteBullet 함수에서 수행하기로 함.
	for (int i=0; i<num_bullet; i++) {
		if (bx0[i]<x1 && x0<bx1[i] && 
			by0[i]<y1 && y0<by1[i]) {
			DeleteBullet(i);
			damage++;
		}
	}
	
	// 원호사격:
	// 메인 캐릭터의 샷 조작에 맞추어 샷을 발사함.
	// 발사의 구체적인 처리는 Shot 함수에서 수행하기로 함.
	if (button) Shot();

	// 피해 정도 판정:
	// 피해가 한계치에 도달하면 제거함 아군이 된 적기를 제거함.
	// 구체적인 처리는
	// DeleteCapturedEnemy 함수에서 수행하기로 함.
	if (damage>=max_damage) DeleteCapturedEnemy();
}
