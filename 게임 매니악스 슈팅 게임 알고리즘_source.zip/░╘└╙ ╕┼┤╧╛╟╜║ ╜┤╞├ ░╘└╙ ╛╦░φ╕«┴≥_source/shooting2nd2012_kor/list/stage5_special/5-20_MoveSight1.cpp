// 상태(보통, 조준, 공격)
typedef enum {
	NORMAL, SIGHT, ATTACK
} STATE_TYPE;

// 메인 캐릭터와 조준을 이동
void MoveSight1(
	float& x, float& y,     // 메인 캐릭터의 좌표
	float& sx, float& sy,   // 조준의 좌표
	float speed,            // 메인 캐릭터의 이동속도
	float sight_speed,      // 조준의 이동속도
	bool up, bool down,     // 스틱 입력(상하)
	bool left, bool right,  // 스틱 입력(좌우)
	bool button             // 조준 버튼의 입력상태
) {
	static int state=NORMAL;  // 상태(처음에는 보통상태에서 시작)
	static int time;          // 공격시간
	
	// 상태에 따라 분기
	switch (state) {
	
		// 보통 상태:
		// 메인 캐릭터를 이동시키고
		// 버튼이 눌렸다면 조준을 표시한 후 조준상태로 이동.
		case NORMAL:
			if (up   ) y-=speed;
			if (down ) y+=speed;
			if (left ) x-=speed;
			if (right) x+=speed;
			if (button) {
				state=SIGHT;
				sx=x; sy=y;
			}
			break;
		
		// 조준 상태:
		// 조준을 이동시키고 버튼이 떼어졌다면 공격상태로 이동.
		case SIGHT:
			if (up   ) sy-=sight_speed;
			if (down ) sy+=sight_speed;
			if (left ) sx-=sight_speed;
			if (right) sx+=sight_speed;
			if (!button) {
				state=ATTACK;
				time=100;
			}
			break;
		
		// 공격 상태:
		// 메인 캐릭터를 이동시키고 일정시간이 지났다면 보통상태로 돌아감.
		case ATTACK:
			if (up   ) y-=speed;
			if (down ) y+=speed;
			if (left ) x-=speed;
			if (right) x+=speed;
			if (time==0) state=NORMAL;
			time--;
			break;
	}
}

