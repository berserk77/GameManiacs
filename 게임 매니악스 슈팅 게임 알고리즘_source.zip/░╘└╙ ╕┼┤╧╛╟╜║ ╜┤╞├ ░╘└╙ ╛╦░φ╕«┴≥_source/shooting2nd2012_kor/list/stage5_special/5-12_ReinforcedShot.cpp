void SpecialShot();
void NormalShot();

void ReinforcedShot(
	float x0, float y0,    // 메인 캐릭터의 좌상좌표
	float x1, float y1,    // 메인 캐릭터의 우하좌표
	float cx0, float cy0,  // 아군 캐릭터의 좌상좌표
	float cx1, float cy1,  // 아군 캐릭터의 우하좌표
	bool button            // 샷 버튼의 상태
) {
	// 아군과 접근하였는지 판정:
	// 접근하였을 경우에는 강한 샷을,
	// 그렇지 않을 경우에는 보통 샷을 발사.
	// 샷을 발사하는 구체적인 처리는
	// SpecialShot, NormalShot 함수에서 각각 수행하기로 함.
	if (button) {
		if (cx0<x1 && x0<cx1 && cy0<y1 && y0<cy1) {
			SpecialShot();
		} else {
			NormalShot();
		}
	}
}

