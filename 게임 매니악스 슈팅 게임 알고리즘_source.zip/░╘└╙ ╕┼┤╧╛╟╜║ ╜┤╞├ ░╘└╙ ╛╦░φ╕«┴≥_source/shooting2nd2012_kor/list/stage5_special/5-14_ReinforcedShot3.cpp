void DeleteShot();
void SpecialShot();

void ReinforcedShot3(
	float sx0, float sy0,  // 샷의 좌상좌표
	float sx1, float sy1,  // 샷의 우하좌표
	float cx0, float cy0,  // 아군의 좌상좌표
	float cx1, float cy1   // 아군의 우하좌표
) {
	// 샷과 아군의 접촉 판정:
	// 접촉하였을 때는 샷을 제거하고
	// 대신에 강한 샷으로 바꿔줌.
	// 구체적인 처리는
	// DeleteShot, SpecialShot 함수에서 각각 수행하기로 함.
	// 샷을 제거하지 않고
	// 샷의 공격력만 바꿔주는 방법도 있음.
	if (cx0<sx1 && sx0<cx1 && cy0<sy1 && sy0<cy1) {
		DeleteShot();
		SpecialShot();
	}
}

