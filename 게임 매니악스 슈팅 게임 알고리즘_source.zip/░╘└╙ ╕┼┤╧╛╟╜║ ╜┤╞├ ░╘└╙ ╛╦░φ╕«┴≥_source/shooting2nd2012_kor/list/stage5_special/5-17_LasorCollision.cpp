void DeleteMyLaser(int id);
void DeleteEnemyLaser(int id);
void SpecialAttack();

void LaserCollision(
	float mx0[], float my0[],  // 메인 캐릭터가 쏜 레이저 파트의 좌상좌표
	float mx1[], float my1[],  // 메인 캐릭터가 쏜 레이저 파트의 우하좌표
	int num_my_lasers,         // 메인 캐릭터가 쏜 레이저 파트의 갯수
	float ex0[], float ey0[],  // 적기가 쏜 레이저 파트의 좌상좌표
	float ex1[], float ey1[],  // 적기가 쏜 레이저 파트의 우하좌표
	int num_enemy_lasers       // 적기가 쏜 레이저 파트의 갯수
) {
	static int energy=0;        // 에너지
	static int min_energy=100;  // 강력한 공격이 발생하기 위해 필요한 에너지
	
	// 레이저끼리 접촉 판정:
	// 메인 캐릭터가 쏜 레이저와 적기가 쏜 레이저가 부딪혔다면
	// 부딪힌 양쪽의 파트를 제거하고 에너지를 늘림.
	// 구체적인 처리는 DeleteMyLaser
	// DeleteEnemyLaser 함수에서 각각 수행하기로 함.
	for (int i=0; i<num_my_lasers; i++) {
		for (int j=0; j<num_enemy_lasers; j++) {
			if (ex0[j]<mx1[i] && mx0[i]<ex1[j] && 
				ey0[j]<my1[i] && my0[i]<ey1[j]) {
				DeleteMyLaser(i);
				DeleteEnemyLaser(j);
				energy++;
			}
		}
	}
	
	// 강력한 공격의 발생 처리:
	// 에너지가 필요치에 도달했다면
	// 강력한 공격을 발생시킴.
	// 구체적인 처리는 SpecialAttack 함수에서 수행하기로 함.
	if (energy>=min_energy) SpecialAttack();
}

