#include <stdlib.h>

// 적기의 간격
#define INTERVAL 6

// 적기의 정보(구조체)
typedef struct ENEMY_STRUCT {
	float X, Y;                 // 현재 좌표
	float OldX[INTERVAL];       // 이전 X좌표
	float OldY[INTERVAL];       // 이전 Y좌표
	int Index;                  // 가장 오래된 좌표를 가리키는 인덱스
	struct ENEMY_STRUCT* Prec;  // 하나 앞의 적기
} ENEMY;

void MoveEnemy(int id);
ENEMY* NewEnemyType();

// 편대 비행 처리
void Formation(
	int num_enemy,  // 적기의 갯수
	ENEMY* enemy[]  // 적기의 정보(구조체를 가리키는 포인터)
) {
	// 적기를 이동
	int i;
	for (i=0; i<num_enemy; i++) {
		ENEMY* self=enemy[i];
		ENEMY* prec=self->Prec;
		
		// 선두 이외의 적기를 움직임:
		// 하나 앞의 적기가 저장해 둔 이전좌표중
		// 가장 오래된 것을 자기자신의 좌표로 설정.
		if (prec) {
			self->X=prec->OldX[prec->Index];
			self->Y=prec->OldY[prec->Index];
		}
		
		// 선두의 적기를 움직임:
		// 구체적인 처리는 MoveEnemy 함수에서 수행하기로 함.
		else {
			MoveEnemy(i);
		}
	}

	// 좌표를 기록:
	// 가장 오래된 좌표를 새로운 좌표로 덮어쓰고
	// 인덱스를 갱신함.
	for (i=0; i<num_enemy; i++) {
		ENEMY* self=enemy[i];
		self->OldX[self->Index]=self->X;
		self->OldY[self->Index]=self->Y;
		self->Index=(self->Index+1)%INTERVAL;
	}
}

// 편대의 생성
void CreateFormation(
	float x, float y,  // 생성 지점의 좌표
	int count          // 편대를 구성하는 적기의 수
) {
	ENEMY* enemy;      // 적기를 나타내는 구조체의 포인터
	ENEMY* prec=NULL;  // 하나 앞의 적기를 가리키는 포인터
	
	// 편대를 구성하는 적기를 만들기:
	// 적기의 구조체를 확보하여 좌표를 초기화함.
	// 구조체를 확보하는 구체적인 처리는 NewEnemyType 함수에서 수행하기로 함.
	for (int i=0; i<count; i++, prec=enemy) {
		enemy=NewEnemyType();
		enemy->X=x;
		enemy->Y=y;
		for (int j=0; j<INTERVAL; j++) {
			enemy->OldX[j]=x;
			enemy->OldY[j]=y;
		}
		enemy->Index=0;

		// 선두 이외의 적기는 하나 앞의 적기를 참조하도록 하고
		// 선두의 적기는 NULL을 참조하도록 함.
		enemy->Prec=prec;
	}
}

