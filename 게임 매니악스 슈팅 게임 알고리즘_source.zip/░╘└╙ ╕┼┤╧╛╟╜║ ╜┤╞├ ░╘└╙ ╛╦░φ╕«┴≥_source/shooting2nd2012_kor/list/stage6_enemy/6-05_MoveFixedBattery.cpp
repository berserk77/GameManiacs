void MoveFixedBattery(
	int num_enemy,           // 적기(고정 대포)의 갯수
	float ex[], float ey[],  // 적기(고정 대포)의 좌표
	float svx, float svy     // 배경의 이동 속도(스크롤 속도)
) {
	// 모든 고정 대포를 배경과 같은 속도로 이동시킴
	for (int i=0; i<num_enemy; i++) {
		ex[i]+=svx;
		ey[i]+=svy;
	}
}

