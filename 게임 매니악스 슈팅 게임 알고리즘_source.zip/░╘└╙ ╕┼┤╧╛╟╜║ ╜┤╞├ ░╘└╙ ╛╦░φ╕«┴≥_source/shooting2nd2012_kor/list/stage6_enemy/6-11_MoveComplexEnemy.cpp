// 적기를 가리키는 구조체
typedef struct {
	float X, Y;  // 적기의 좌표
} ENEMY;

// 보스(복잡한 구조의 적기)를 나타내는 구조체
#define MAX_PART 32
typedef struct {
	float X, Y;             // 보스의 좌표
	ENEMY* Part[MAX_PART];  // 보스를 구성하는 부품(적기)
	int NumPart;            // 부품 (적기)의 갯수
	bool Fatal[MAX_PART];   // 치명적인 부품인가?
} COMPLEX_ENEMY;

void MoveEnemy(ENEMY* enemy);
void DrawEnemy(ENEMY* enemy, float x, float y);
bool Destroyed(ENEMY* enemy);
void DeleteEnemy(ENEMY* enemy);
void DeleteEnemy(COMPLEX_ENEMY* enemy);

// 보스를 움직이기:
// 보스를 구성하는 모든 적기에 대하여 순서대로 처리를 수행함.
void MoveComplexEnemy(COMPLEX_ENEMY* ce) {
	for (int i=0; i<ce->NumPart; i++) {

		// 적기를 움직이기:
		// 구체적인 처리는 MoveEnemy함수에서 수행함.
		MoveEnemy(ce->Part[i]);

		// 적기를 표시하기:
		// 모든 부품이 하나가 되어 움직이도록
		// 부품의 좌표를 보스 좌표로부터 상대 위치가 되도록 사용함.
		// 보스 전체를 움직이기 위해서는 ce->X와 ce->Y를 갱신함.
		// 구체적인 처리는 DrawEnemy함수에서 수행함.
		DrawEnemy(ce->Part[i],
			ce->Part[i]->X+ce->X, ce->Part[i]->Y+ce->Y);

		// 적기의 파괴:
		// 판정과 파괴의 구체적인 처리는 각각
		// Destroyed，DeleteEnemy함수에서 수행함.
		if (Destroyed(ce->Part[i])) {
			DeleteEnemy(ce->Part[i]);

			// 보스 전체의 파괴:
			// 치명적인 부품이 파괴되었을 때는
			// 보스 전체를 파괴시킴.
			if (ce->Fatal[i]) DeleteEnemy(ce);
		}
	}
}

