void DeleteEnemy(int id);

void OrbitalFlight(
	int num_enemy,           // 적기의 数
	float ex[], float ey[],  // 적기의 좌표
	int index[],             // 궤도 데이터를 가리키는 인덱스
	int num_orbit,           // 궤도 데이터의 요소수
	float ox[], float oy[]   // 궤도 데이터(좌표)
) {
	for (int i=0; i<num_enemy; i++) {
		
		// 적기 좌표의 갱신:
		// 궤적 데이터를 읽어서 적기의 새로운 좌표로 설정함.
		ex[i]=ox[index[i]];
		ey[i]=oy[index[i]];
		
		// 인덱스(데이터를 읽을 위치)를 진행시킴:
		// 궤도 데이터의 마지막에 도달하였다면 적기를 제거함.
		// 적기를 제거하는 구체적인 처리는 DeleteEnemy 함수에서 수행하기로 함.
		// 
		index[i]++;
		if (index[i]==num_orbit) DeleteEnemy(i);
	}
}

