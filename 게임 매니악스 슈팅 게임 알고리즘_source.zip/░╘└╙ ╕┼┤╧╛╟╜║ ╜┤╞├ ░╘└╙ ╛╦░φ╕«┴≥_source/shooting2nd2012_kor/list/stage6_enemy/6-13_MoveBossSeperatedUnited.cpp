// 보스를 나타내는 구조체
#define MAX_PART 32
typedef struct BOSS_STRUCT {
	float X, Y;          // 보스의 좌표
	struct BOSS_STRUCT* 
		Part[MAX_PART];  // 보스를 구성하는 부품(보스)
	int NumPart;         // 부품의 갯수
	float PX[MAX_PART], 
		PY[MAX_PART];    // 부품의 상대 좌표
} BOSS;

void MoveBoss(BOSS* boss);

// 분리중의 움직임:
// 각 부품을 독립적으로 움직임.
// 구체적인 이동 처리는 MoveBoss함수에서 수행함.
void MoveSeparatedBoss(BOSS* boss) {
	for (int i=0; i<boss->NumPart; i++) {
		MoveBoss(boss->Part[i]);
	}
}

// 합체중의 움직임:
// 모든 부품이 하나가 되어 움직이도록
// 중심이 되는 좌표에 대해 고정됭 위치에 부품을 배치함.
// 구체적인 이동 처리는 MoveBoss함수에서 수행함.
void MoveUnitedBoss(BOSS* boss) {
	MoveBoss(boss);
	for (int i=0; i<boss->NumPart; i++) {
		boss->Part[i]->X=boss->X+boss->PX[i];
		boss->Part[i]->Y=boss->Y+boss->PY[i];
	}
}

