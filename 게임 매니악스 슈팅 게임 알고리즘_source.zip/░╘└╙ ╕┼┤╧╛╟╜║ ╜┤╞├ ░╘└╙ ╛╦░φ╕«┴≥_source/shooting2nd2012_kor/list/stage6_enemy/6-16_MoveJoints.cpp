#include <math.h>

void MoveJoints(
	int num_joint,         // 관절의 갯수
	float x[], float y[],  // 관절의 좌표
	float rad[],           // 관절의 회전 각도
	float vrad,            // 관절이 회전하는 속도
	float lrad,            // 화전 각도의 한계값
	float dist,            // 관절간의 거리
	float tx, float ty     // 목표 좌표
) {
	int i;
	float c, s;
	
	// 전반부 처리:
	// 선두에서 뿌리를 향해 차례대로 관절의 각도를 정함.
	c=(float)cos(vrad);
	s=(float)sin(vrad);
	for (i=1; i<num_joint; i++) {
		float dxt, dyt;       // 관절에서 목표물을 향하는 벡터
		float dxn, dyn;       // 관절에서 선두를 향하는 벡터
		float dxr=0, dyr=0;   // 시계방향 벡터
		float dxl=0, dyl=0;   // 시계 반대방향 벡터
		float dpn, dpr, dpl;  // 내적(회전하지 않을 경우, 시계방향 회전, 시계 반대방향 회전)
		
		// 관절에서 목표물을 향하는 벡터를 계산
		dxt=tx-x[i];
		dyt=ty-y[i];

		// 관절에서 선두를 향하는 벡터와 내적을 계산
		// (회전하지 않을 경우의 벡터)
		dxn=x[0]-x[i];
		dyn=y[0]-y[i];
		dpn=dxt*dxn+dyt*dyn;
		
		// 시계 방향 회전시의 벡터 계산:
		// 회전 각도의 한계치를 넘을 때는 회전하지 않음
		if (rad[i]+vrad<=lrad) {
			dxr=c*dxn-s*dyn;
			dyr=s*dxn+c*dyn;
			dpr=dxt*dxr+dyt*dyr;
		} else dpr=dpn;
		
		// 시계 반대방향 회전시의 벡터 계산:
		// 회전 각도의 한계치를 넘을 때는 회전하지 않음
		if (rad[i]-vrad>=-lrad) {
			dxl= c*dxn+s*dyn;
			dyl=-s*dxn+c*dyn;
			dpl=dxt*dxl+dyt*dyl;
		} else dpl=dpn;
		
		// 회전 방향의 선택:
		// 내적을 비교하여 3가지 중에서 고름.
		// 선두를 회전시켜 새로운 선두의 위치를 구함.
		if (dpr>dpn && dpr>dpl) {
			rad[i]+=vrad;
			x[0]=x[i]+dxr;
			y[0]=y[i]+dyr;
		}
		if (dpl>dpn && dpl>dpr) {
			rad[i]-=vrad;
			x[0]=x[i]+dxl;
			y[0]=y[i]+dyl;
		}
	}
	
	// 후반부 처리:
	// 뿌리에서 선두를 향해 관절의 위치를 구함.
	float px=dist, py=0, qx, qy;
	for (i=num_joint-2; i>=0; i--) {
		c=(float)cos(rad[i+1]);
		s=(float)sin(rad[i+1]);
		qx=c*px-s*py;
		qy=s*px+c*py;
		x[i]=x[i+1]+qx;
		y[i]=y[i+1]+qy;
		px=qx;
		py=qy;
	}
}
