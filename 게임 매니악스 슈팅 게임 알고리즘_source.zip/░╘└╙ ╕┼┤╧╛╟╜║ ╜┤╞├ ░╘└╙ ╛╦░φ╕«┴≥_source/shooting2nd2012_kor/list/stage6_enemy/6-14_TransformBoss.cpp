// 보스를 나타내는 구조체
#define MAX_PART 32
#define MAX_FORM 8
typedef struct BOSS_STRUCT {
	float X, Y;                  // 보스의 좌표
	struct BOSS_STRUCT* 
		Part[MAX_PART];          // 보스를 구성하는 부품(보스)
	int NumPart;                 // 부품의 갯수
	float 
		PX[MAX_PART][MAX_FORM],  // 부품의 상대 좌표
		PY[MAX_PART][MAX_FORM];  // [부품 번호][형태 번호]
} BOSS;

// 변신:
// 각 부품을 변신 전의 위치에서 변신 후의 위치로 이동시키기.
// 변신에 걸리는 시간과 타이머의 비율로부터，
// 이동 도중의 위치를 계산함.
#define TRANSFORM_TIME 180
void TransformBoss(
	BOSS* boss,  // 보스 구조체를 가리키는 포인터
	int from,    // 변신 전의 형태 번호
	int to,      // 변션 후의 형태 번호
	int& timer   // 타이머
) {
	float ratio=(float)timer/TRANSFORM_TIME;
	for (int i=0; i<boss->NumPart; i++) {
		boss->Part[i]->X=
			boss->PX[i][from]*(1-ratio)+
			boss->PX[i][to]*ratio;
		boss->Part[i]->Y=
			boss->PY[i][from]*(1-ratio)+
			boss->PY[i][to]*ratio;
	}
}

