void DeleteEnemy(int id);
void DeleteWeapon(int id);

void BreakableEnemy(
	int num_enemy,             // 적기의 갯수
	float ex0[], float ey0[],  // 적기의 접촉 판정 영역의 좌상좌표
	float ex1[], float ey1[],  // 적기의 접촉 판정 영역의 우하좌표
	float vit[],               // 적기의 내구력
	int num_weapon,            // 무기의 갯수
	float wx0[], float wy0[],  // 무기의 접촉 판정 영역의 좌상좌표
	float wx1[], float wy1[],  // 무기의 접촉 판정 영역의 우하좌표
	float str[]                // 무기의 공격력
) {
	// 적기와 무기의 접촉 판정:
	// 모든 적기와 무기에 대하여
	// 무기가 적기에 닿았는지 판정하기.
	for (int i=0; i<num_enemy; i++) {
		for (int j=0; j<num_weapon; j++) {
			if (ex0[i]<wx1[j] && wx0[j]<ex1[i] && 
				ey0[i]<wy1[j] && wy0[j]<ey1[i]
			) {
				// 명중했을 경우:
				// 무기의 공격력으로 적기의 내구력을 깎고
				// 내구력이 0 혹은 음의 값이 되었다면 적기를 파괴시킴.
				// 파괴의 구체적인 처리는
				// DeleteEnemy 함수에서 수행하기로 함.
				vit[i]-=str[j];
				if (vit[i]<=0) DeleteEnemy(i);
				
				// 적기에 명중한 무기는 제거함:
				// 구체적인 처리는 DeleteWeapon 함수에서 수행하기로 함.
				DeleteWeapon(j);
			}
		}
	}
}

