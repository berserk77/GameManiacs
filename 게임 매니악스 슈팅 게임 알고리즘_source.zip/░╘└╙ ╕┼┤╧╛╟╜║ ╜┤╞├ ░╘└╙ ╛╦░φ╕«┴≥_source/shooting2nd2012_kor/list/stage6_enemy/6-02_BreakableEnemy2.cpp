void DeleteEnemy(int id);
void DeleteWeapon(int id);

// 적기의 타입을 나타내는 상수:
// 파괴가능한 적기, 파괴불가능한 적기, 무기로 맞출 수 없는 적기
typedef enum {
	BREAKABLE, UNBREAKABLE, TRANSPARENT
} ENEMY_TYPE;

// (파괴할 수 없는 적기도 포함한)적기의 처리
void BreakableEnemy2(
	int num_enemy,             // 적기의 갯수
	ENEMY_TYPE type[],         // 적기의 타입
	float ex0[], float ey0[],  // 적기의 접촉 판정 영역의 좌상좌표
	float ex1[], float ey1[],  // 적기의 접촉 판정 영역의 우하좌표
	float vit[],               // 적의 내구력
	int num_weapon,            // 무기의 갯수
	float wx0[], float wy0[],  // 무기의 접촉 판정 영역의 좌상좌표
	float wx1[], float wy1[],  // 무기의 접촉 판정 영역의 우하좌표
	float str[]                // 무기의 공격력
) {
	// 모든 적기에 대하여 처리
	for (int i=0; i<num_enemy; i++) {
		
		// 무기로 맞출 수 없는 적기의 경우:
		// 접촉 판정 처리를 수행하지 않고
		// 다음 적기로 건너뜀
		if (type[i]==TRANSPARENT) continue;
		
		// 적기와 무기의 접촉 판정
		for (int j=0; j<num_weapon; j++) {
			if (ex0[i]<wx1[j] && wx0[j]<ex1[i] && 
				ey0[i]<wy1[j] && wy0[j]<ey1[i]
			) {
				// 파괴가능한 적기에 명중했을 경우:
				// 무기의 공격력으로 적기의 내구력을 깎고
				// 내구력이 0혹은 음의 값이 되었다면 적기를 파괴함.
				// 파괴의 구체적인 처리는
				// DeleteEnemy 함수에서 수행하기로 함.
				if (type[i]==BREAKABLE) {
					vit[i]-=str[j];
					if (vit[i]<=0) DeleteEnemy(i);
				}
				
				// 적기에 명중한 무기는 제거함:
				// 구체적인 처리는 DeleteWeapon 함수에서 수행하기로 함.
				DeleteWeapon(j);
			}
		}
	}
}


