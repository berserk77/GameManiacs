// 사각형의 접촉 판정 영역을 가리키는 구조체
typedef struct {
	float Left, Top, Right, Bottom;
} HIT;

// 복잡한 접촉 판정 영역을 나타내는 구조체
#define MAX_HIT 32
typedef struct {
	HIT* Hit[MAX_HIT];  // 사각형의 접촉 판정 영역
	int Num;            // 접촉 판정 영역의 갯수
} COMPLEX_HIT;

// "사각형" 대 "사각형"의 기본적인 접촉 판정 처리
bool IsHit(HIT* a, HIT* b) {
	return
		a->Left<b->Right && b->Left<a->Right && 
		a->Top<b->Bottom && b->Top<a->Bottom;
}

// "사각형" 대 "복잡한 모양"의 접촉 판정 처리:
// 복수의 사각형에 대하여 차례대로 접촉 판정 처리를 수행하여
// 어느 하나라도 닿았다면 "접촉"으로 판정함.
bool IsHit(COMPLEX_HIT* a, HIT* b) {
	for (int i=0; i<a->Num; i++) {
		if (IsHit(a->Hit[i], b)) return true;
	}
	return false;
}

// "복잡한 모양" 대 "복잡한 모양"의 접촉 판정 처리:
// 모든 조합에 대하여 접촉 판정 처리를 수행하여
// 어느 하나라도 조건이 성립했다면 "접촉"으로 판정함.
bool IsHit(COMPLEX_HIT* a, COMPLEX_HIT* b) {
	for (int i=0; i<a->Num; i++) {
		for (int j=0; j<b->Num; j++) {
			if (IsHit(a->Hit[i], b->Hit[j])) return true;
		}
	}
	return false;
}

