// 보스의 상태:
// 공격0, 공격1, 공격2, 대기
typedef enum {
	ATTACK0, ATTACK1, ATTACK2, WAIT
} BOSS_STATE;

void Attack0();
void Attack1();
void Attack2();

// 각 상태의 제한시간
int Time[]={30, 40, 25, 20};

// 보스의 행동
void MoveBoss(
	BOSS_STATE& state,  // 현재 상태
	int& timer           // 타이머
) {
	// 공격:
	// 현재 상태에 따른 공격을 수행함. 대기 상태일 때는 아무 것도 수행하지 않음.
	// 구체적인 공격 처리는 각각
	// Attack0，Attack1，Attack2함수에서 수행함.
	switch (state) {
		case ATTACK0: Attack0(); break;
		case ATTACK1: Attack1(); break;
		case ATTACK2: Attack2(); break;
	}
	
	// 상태 전이:
	// 타이머 값을 증가시켜
	// 현재 상태의 제한시간을 초과했다면 다음 상태로 넘어감.
	timer++;
	if (timer>Time[state]) {
		state=(BOSS_STATE)((state+1)%4);
		timer=0;
	}
}

