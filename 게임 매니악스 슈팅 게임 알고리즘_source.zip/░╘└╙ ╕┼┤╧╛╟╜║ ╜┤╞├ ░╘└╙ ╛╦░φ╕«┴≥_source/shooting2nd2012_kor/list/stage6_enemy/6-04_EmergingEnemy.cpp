void MoveEnemy(int id);
void DeleteEnemy(int id);
void DrawEnemy(float x, float y, float alpha);

// 적기의 상태를 나타내는 상수:
// 준비(등장전), 등장, 활동, 소실
typedef enum {
	READY, APPEAR, ACT, DISAPPEAR
} STATE_TYPE;

// 등장과 소실에 걸리는 시간, 활동시간
#define TIME 30
#define ACT_TIME 180

// 허공에 나타나는 적기의 처리
void EmergingEnemy(
	int num_enemy,           // 적기의 갯수
	STATE_TYPE state[],      // 적기의 상태
	float ex[], float ey[],  // 적기의 좌표
	float alpha[],           // 알파 값
	int timer[]              // 타이머
) {
	// 모든 적기에 대하여 처리
	for (int i=0; i<num_enemy; i++) {
		
		// 상태에 따라 분기
		switch (state[i]) {
			
			// 준비(등장전):
			// 알파 값과 타이머 값을 초기화하고
			// 등장 상태로 이동.
			case READY:
				state[i]=APPEAR;
				alpha[i]=0;
				timer[i]=TIME;
				break;
			
			// 등장:
			// 알파 값을 점점 늘려줌.
			// 타이머가 0이 되었다면 활동 상태로 이동.
			case APPEAR:
				alpha[i]=(float)(TIME-timer[i])/TIME;
				timer[i]--;
				if (timer[i]==0) {
					state[i]=ACT;
					timer[i]=ACT_TIME;
				}
				break;
			
			// 활동:
			// 이동, 공격을 수행.
			// 타이머가 0이 되었다면 소실 상태로 이동.
			// 이동이나 공격의 구체적인 처리는
			// MoveEnemy 함수에서 수행하기로 함.
			case ACT:
				MoveEnemy(i);
				timer[i]--;
				if (timer[i]==0) {
					state[i]=DISAPPEAR;
					timer[i]=TIME;
				}
				break;
			
			// 소실:
			// 알파 값을 점점 작게 해 줌.
			// 타이머가 0이 되었다면 적기를 제거함.
			// 적기를 제거하는 구체적인 처리는
			// DeleteEnemy 함수에서 수행하기로 함.
			case DISAPPEAR:
				alpha[i]=(float)timer[i]/TIME;
				timer[i]--;
				if (timer[i]==0) {
					DeleteEnemy(i);
				}
				break;
		}
		
		// 적기의 표시:
		// 알파 값에 따라 알파 합성(알파 블렌딩)을 해서 표시함.
		DrawEnemy(ex[i], ey[i], alpha[i]);
	}
}
