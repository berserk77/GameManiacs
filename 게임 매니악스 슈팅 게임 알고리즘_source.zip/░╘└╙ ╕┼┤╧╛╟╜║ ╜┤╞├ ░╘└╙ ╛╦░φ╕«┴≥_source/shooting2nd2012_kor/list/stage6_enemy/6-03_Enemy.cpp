void MoveEnemy(int id);
void DeleteEnemy(int id);

void Enemy(
	int num_enemy,             // 적기의 갯수
	float ex0[], float ey0[],  // 적기의 접촉 판정 영역의 좌상좌표
	float ex1[], float ey1[],  // 적기의 접촉 판정 영역의 우하좌표
	float sx0, float sy0,      // 이동 가능 영역(화면 둘레)의 좌상좌표
	float sx1, float sy1       // 이동 가능 영역(화면 둘레)의 우하좌표
) {
	for (int i=0; i<num_enemy; i++) {
		
		// 적기의 이동:
		// 이동의 구체적인 처리는 DeleteEnemy 함수에서 수행하기로 함.
		MoveEnemy(i);
		
		// 적기의 제거:
		// 적기가 화면에서 사라졌는지 판정하여
		// 사라졌다면 제거함.
		// 제거의 구체적인 처리는 DeleteEnemy 함수에서 수행하기로 함.
		if (ex1[i]<=sx0 || sx1<=ex0[i] || 
			ey1[i]<=sy0 || sy1<=ey0[i]) {
			DeleteEnemy(i);
		}
	}
}

