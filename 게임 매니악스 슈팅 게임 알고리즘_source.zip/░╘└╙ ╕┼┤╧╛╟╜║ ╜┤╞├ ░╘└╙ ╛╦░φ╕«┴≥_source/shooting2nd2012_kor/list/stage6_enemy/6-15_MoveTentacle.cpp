#include <math.h>

void MoveTentacle(
	float x[], float y[],  // 각 파트의 좌표
	int num_part,          // 파트의 갯수
	float tx, float ty,    // 목표 좌표
	float v,               // 선두의 이동 속도
	float limit,           // 선두와 뿌리의 최대 거리
	int num_loop           // 계산을 반복할 횟수
) {
	// 선두의 좌표와 뿌리의 좌표
	float hx=x[0], hy=y[0];
	float rx=x[num_part-1], ry=y[num_part-1];

	// 목표 방향으로 선두를 이동
	hx+=(tx>=hx+v ? v : (tx<=hx-v ? -v : 0));
	hy+=(ty>=hy+v ? v : (ty<=hy-v ? -v : 0));

	// 선두의 이동 범위를 제한하기:
	// 선두와 뿌리의 거리가 한계치를 넘었다면
	// 이동 가능 범위 안으로 되돌림.
	float dx=hx-rx, dy=hy-ry;
	float d=sqrt(dx*dx+dy*dy);
	if (d>limit) {
		hx=dx*limit/d+rx;
		hy=dy*limit/d+ry;
	}

	// 중간 부분의 좌표를 게산하기:
	// 인접 부분의 좌표의 평균을 구함.
	// 계산은 선두에서 뿌리쪽을 향해 실시함.
	// 필요에 따라서 계산을 여러번 반복해 줌.
	x[0]=hx; y[0]=hy;
	for (int l=0; l<num_loop; l++) {
		for (int i=1; i<num_part-1; i++) {
			x[i]=(x[i-1]+x[i+1])/2;
			y[i]=(y[i-1]+y[i+1])/2;
		}
	}
}

