#include <stdlib.h>

bool Destroyed();
void AimingBullet(float ex, float ey, float tx, float ty);
void Delete();

void Revenge(
	float rate,          // 반격을 실시할 확률
	float ex, float ey,  // 적기의 좌표
	float tx, float ty   // 목표물(메인 캐릭터)의 좌표
) {
	// 적기가 파괴되었는지 판정:
	// 구체적인 처리는 Detroyed 함수에서 수행하기로 함.
	if (Destroyed()) {
	
		// 반격:
		// 난수를 사용하여 일정 확률로 반격.
		// 반격탄은 "조준탄"과 동일함.
		// 발사의 구체적인 처리는 AimingBullet 함수에서 수행하기로 함.
		if (rand()<=rate*RAND_MAX) {
			AimingBullet(ex, ey, tx, ty);
		}
		
		// 적기를 제거:
		// 구체적인 처리는 Delete 함수에서 수행하기로 함.
		Delete();
	}
}

