void DrawChip(int id, int x, int y);

// 칩의 갯수(X방향, Y방향)
#define XMAX 1000
#define YMAX 50

// 상하좌우가 연결된 배경의 표시
void DrawCirculatedBG(
	int sx, int sy,      // 화면 왼쪽 위에 해당하는 배경상의 위치
	int sw, int sh,      // 화면의 크기
	int cw, int ch,      // 칩의 크기
	int map[XMAX][YMAX]  // 배경 데이터(칩 번호의 배열)
) {
	// 표시할 칩의 범위
	int x0=sx/cw, y0=sy/ch;    // 왼쪽 위 가장자리의 칩
	int x1=(sx+sw-1)/cw%XMAX, 
		y1=(sy+sh-1)/ch%YMAX;  // 오른쪽 아래 가장자리의 칩

	// 칩의 표시:
	// 칩의 표시는 DrawChip 함수에서 수행하기로 함.
	for (int i=x0; i!=x1+1; i=(i+1)%XMAX) {
		for (int j=y0; j!=y1+1; j=(j+1)%YMAX) {
			DrawChip(map[i][j], j*cw-sx, i*ch-sy);
		}
	}
}
