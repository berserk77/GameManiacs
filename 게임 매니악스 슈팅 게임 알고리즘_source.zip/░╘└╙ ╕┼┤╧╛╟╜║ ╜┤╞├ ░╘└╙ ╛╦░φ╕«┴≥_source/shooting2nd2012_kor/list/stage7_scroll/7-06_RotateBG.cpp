#include <math.h>

void DrawChip(int id, int x, int y);

// 칩의 갯수(X방향, Y방향)
#define XMAX 20
#define YMAX 400

// 배경의 표시
void RotateBG(
	int sx, int sy,      // 화면의 중심좌표
	int sw, int sh,      // 화면의 크기
	int cw, int ch,      // 칩의 크기
	int map[YMAX][XMAX]  // 배경 데이터(칩 번호의 배열)
) {
	// 회전후에 화면안에 들어오는 배경의 최대 범위를 구함
	int w2=sw/2, h2=sh/2;            // 화면의 폭과 높이의 1/2
	int r=(int)sqrt(w2*w2+h2*h2);    // 원의 반경
	int x0=(sx-r)/cw, y0=(sy-r)/ch;  // 왼쪽 위 가장자리의 칩
	int x1=(sx+r)/cw, y1=(sy+r)/ch;  // 오른쪽 아래 가장자리의 칩

	// 칩의 표시:
	// 칩의 표시는 DrawChip 함수에서 수행하기로 함.
	for (int i=y0; i<=y1; i++) {
		for (int j=x0; j<=x1; j++) {
			DrawChip(map[i][j], j*cw-sx+sw/2, i*ch-sy+sh/2);
		}
	}
}

