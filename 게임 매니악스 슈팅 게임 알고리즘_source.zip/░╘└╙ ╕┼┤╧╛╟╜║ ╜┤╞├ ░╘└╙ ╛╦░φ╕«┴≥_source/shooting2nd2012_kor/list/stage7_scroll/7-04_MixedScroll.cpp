void DrawBG(int x, int y);
void DrawMyShip(int x, int y);

void MixedScroll(
	int x, int y,  // 메인 캐릭터의 배경상의 좌표
	int w,         // 메인 캐릭터의 폭
	int sy,        // 스크롤 위치의 Y좌표
	int svy,       // Y방향의 스크롤 속도
	int sw,        // 화면 폭
	int bw         // 배경의 폭
) {
	// 배경의 표시:
	// 스크롤 위치를 갱신하여 배경을 표시함.
	// 배경을 표시하는 구체적인 처리는 DrawBG 함수에서 수행하기로 함.
	int sx=(bw-sw)*x/(bw-w);
	sy+=svy;
	DrawBG(sx, sy);
	
	// 메인 캐릭터의 표시:
	// 스크롤 위치에서의 상대위치에 표시함.
	// 메인 캐릭터를 표시하는 구체적인 처리는 DrawMyShip 함수에서 수행하기로 함.
	DrawMyShip(x-sx, y-sy);
}

