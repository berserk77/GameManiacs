void ScrollForce(
	int& x, int& y,   // 메인 캐릭터의 좌표
	int vx, int vy,   // 메인 캐릭터의 속도
	int svx, int svy  // 스크롤 속도
) {
	x+=vx+svx/2;
	y+=vy+svy/2;
}

