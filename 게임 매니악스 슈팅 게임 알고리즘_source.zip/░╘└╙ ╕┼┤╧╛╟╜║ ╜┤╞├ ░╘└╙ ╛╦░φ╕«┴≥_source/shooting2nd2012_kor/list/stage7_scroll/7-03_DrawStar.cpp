void DrawPixel(int x, int y, int color);

// 별의 정보를 저장하는 구조체
typedef struct {
	int X, Y;    // 좌표
	int VX, VY;  // 속도
	int Color;     // 色
} STAR;

// 별의 스크롤
void DrawStar(
	int num_star,   // 별의 갯수
	STAR star[]    // 별의 정보
) {
	// 별의 이동과 표시:
	// 별을 표시하는 구체적인 처리는 DrawPixel 함수에서 수행하기로 함.
	for (int i=0; i<num_star; i++) {
		star[i].X+=star[i].VX;
		star[i].Y+=star[i].VY;
		DrawPixel(star[i].X, star[i].Y, star[i].Color);
	}
}

