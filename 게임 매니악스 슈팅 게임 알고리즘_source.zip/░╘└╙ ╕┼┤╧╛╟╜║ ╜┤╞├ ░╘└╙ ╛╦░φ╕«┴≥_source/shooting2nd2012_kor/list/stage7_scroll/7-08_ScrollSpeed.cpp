void ScrollSpeed(
	int y,               // 메인 캐릭터의 Y좌표
	int& svy,            // 스크롤 속도 (Y방향)
	int ymin, int ymax,  // 메인 캐릭터의 Y좌표의 최대치, 최소치
	int smax, int smin   // 스크롤의 최대, 최소 스피드
) {
	svy=smin+(y-ymin)*(smax-smin)/(ymax-ymin);
}

