void DrawBG(int id);

void OverlaidScroll(
	int num_bg,           // 배경의 갯수
	int sx[], int sy[],   // 각 배경상의 표시위치
	int svx[], int svy[]  // 각 배경의 스크롤 속도
) {
	// 모든 배경의 표시:
	// 각 배경의 표시위치를  순서대로 갱신한 후에 표시함.
	// 배경을 표시하는 구체적인 처리는 DrawBG 함수에서 수행하기로 함.
	for (int i=0; i<num_bg; i++) {
		sx[i]+=svx[i];
		sy[i]+=svy[i];
		DrawBG(i);
	}
}

