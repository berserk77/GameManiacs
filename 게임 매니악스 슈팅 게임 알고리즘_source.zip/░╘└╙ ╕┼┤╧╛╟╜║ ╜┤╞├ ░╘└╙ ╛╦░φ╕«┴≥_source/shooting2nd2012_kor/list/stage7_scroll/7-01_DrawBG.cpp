void DrawChip(int id, int x, int y);

// 칩의 수(X방향, Y방향)
#define XMAX 20
#define YMAX 400

// 배경의 표시
void DrawBG(
	int sx, int sy,      // 화면 왼쪽 위에 해당하는 배경상의 위치
	int sw, int sh,      // 화면의 크기
	int cw, int ch,      // 칩의 크기
	int map[YMAX][XMAX]  // 배경 데이터(칩 번호의 배열)
) {
	// 표시할 칩의 범위
	int x0=sx/cw, y0=sy/ch;                // 왼쪽 위 가장자리의 칩
	int x1=(sx+sw-1)/cw, y1=(sy+sh-1)/ch;  // 오른쪽 아래 가장자리의 칩

	// 칩의 표시:
	// 칩의 표시는 はDrawChip 함수에서 수행하기로 함.
	for (int i=y0; i<=y1; i++) {
		for (int j=x0; j<=x1; j++) {
			DrawChip(map[i][j], j*cw-sx, i*ch-sy);
		}
	}
}

