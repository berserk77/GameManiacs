void ShotPower(
	float& x, float& y,  // 샷의 좌표
	float vx, float vy,  // 샷의 속도
	float& power,        // 샷의 위력
	float attenuation    // 위력이 감쇄하는 정도
) {
	// 샷을 이동시킴
	x+=vx; y+=vy;
	
	// 이동할 때마다 샷의 위력을 약하게 함
	power-=attenuation;
}

