void Shot();
void Laser();

void ShotAndLaser(
	bool button,    // 버튼 상태 (눌렸으면 true)
	int min_power,  // 에너지 샷이 발사될 최소한의 파워
	int max_gauge   // 연사 게이지의 최대치
) {
	// 모은 에너지, 연사 게이지
	static int power=0, gauge=0;

	// 버튼을 누르고 있을 때:
	if (button) {
		
		// 에너지가 부족할 경우:
		// 에너지를 늘려주고 연사 게이지를 최대값으로 하여
		// 샷을 발사함. 구체적인 처리는 Shot 함수에서 수행하기로 함.
		if (power<min_power) {
			power++;
			gauge=max_gauge;
			Shot();
		}
	
		// 에너지가 충분한 경우:
		// 연사 게이지를 0으로 하고 레이저를 발사.
		// 구체적인 처리는 Laser 함수에서 수행하기로 함.
		else {
			gauge=0;
			Laser();
		}
	}
	
	// 버튼을 누르고 있지 않을 때:
	else {
		
		// 연사 게이지가 0보다 클 경우:
		// 보통 샷을 쏘고 연사 게이지를 1 감소시킴.
		if (gauge>0) {
			Shot();
			gauge--;
		}

		// 에너지를 0으로 함.
		power=0;
	}
}

