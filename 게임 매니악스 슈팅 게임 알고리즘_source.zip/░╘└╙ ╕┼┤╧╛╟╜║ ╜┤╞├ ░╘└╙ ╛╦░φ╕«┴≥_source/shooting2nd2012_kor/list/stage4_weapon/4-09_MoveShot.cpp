void DeleteShot();

void MoveShot(
	float& x0, float& y0,  // 샷의 좌상좌표
	float& x1, float& y1,  // 샷의 우하좌표
	float vx, float vy,    // 샷의 속도(X방향, Y방향)
	float sx0, float sy0,  // 화면 둘레의 좌상좌표
	float sx1, float sy1   // 화면 둘레의 우하좌표
) {
	// 샷이 화면 밖으로 빠져 나가면 제거하기:
	// 구체적인 처리는 DeleteShot 함수에서 수행하기로 함.
	if (x1<=sx0 || sx1<=x0 || y1<=sy0 || sy1<=y0) DeleteShot();

	// 샷을 이동시킴 (좌표를 갱신)
	x0+=vx; y0+=vy;
	x1+=vx; y1+=vy;
}

