void Shot();

void AutoShot(
	bool button  // 버튼 상태 (눌렸으면 true)
) {
	// 샷의 발사:
	// 버튼이 눌려지면 샷을 발사하기.
	// 발사에 관한 상세한 처리는 Shot 함수에서 수행하기로 함.
	if (button) Shot();
}

