void DeleteOpponent();
void DeleteShot();

void HitShot(
	float x0, float y0,    // 샷의 접촉 판정 영역의 좌상좌표
	float x1, float y1,    // 샷의 접촉 판정 영역의 우하좌표
	float attack,          // 샷의 공격력
	float ox0, float oy0,  // 목표물의 접촉 판정 영역의 좌상좌표
	float ox1, float oy1,  // 목표물의 접촉 판정 영역의 우하좌표
	float endurance,       // 목표물의 내구력
	bool invincible        // 목표물이 파괴가능한지 아닌지를 나타내는 플래그
) {
	// 샷이 목표물에 접촉했을 경우
	if (ox0<x1 && x0<ox1 && oy0<y1 && y0<oy1) {

		// 목표물이 무적상태가 아닐 경우:
		// 샷의 공격력으로 목표물의 내구력을 깎고,
		// 내구력이 0이 되면 목표물을 제거함.
		// 구체적인 처리는 DeleteOpponent 함수에서 수행하기록 함.
		if (!invincible) {
			endurance-=attack;
			if (endurance<0) DeleteOpponent();
		}
		
		// 샷을 제거하기:
		// 구체적인 DeleteShot 함수에서 수행하기로 함.
		// 여기서 샷을 제거하지 않으면 관통탄이 됨.
		DeleteShot();
	}
}

