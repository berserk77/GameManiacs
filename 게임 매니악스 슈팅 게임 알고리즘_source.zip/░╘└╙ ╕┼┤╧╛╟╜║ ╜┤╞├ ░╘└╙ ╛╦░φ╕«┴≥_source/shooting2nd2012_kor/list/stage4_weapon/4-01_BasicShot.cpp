void Shot();

void BasicShot(
	bool button  // 지금 버튼 상태 (눌렸으면 true)
) {
	// 이전의 버튼 상태 (눌렸으면 true)
	static bool prev_button=false;
	
	// 샷의 발사:
	// 이전에 버튼이 눌려져 있지 않았다가 지금 버튼일 눌렸을 때만
	// 샷을 발사하기.
	// 샷을 발사하는 자세한 처리는 Shot 함수에서 수행하기로 함.
	if (!prev_button && button) Shot();
	
	// 지금 버튼 상태를 저장해 둠
	prev_button=button;
}

