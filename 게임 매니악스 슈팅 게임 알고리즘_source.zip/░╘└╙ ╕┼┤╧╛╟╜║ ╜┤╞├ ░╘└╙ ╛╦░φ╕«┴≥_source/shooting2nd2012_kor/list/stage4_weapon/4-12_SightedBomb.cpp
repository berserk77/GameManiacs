void Explode();
void DrawMyShip(float x, float y);
void DrawScope(float x, float y);
void DrawTarget(float x, float y);
void DrawBomb(float x, float y);

void SightedBomb(
	float x, float y,        // 메인 캐릭터의 좌표
	float sx, float sy,      // 조준의 좌표
	float bvx, float bvy,    // 폭탄의 속도
	bool button              // 버튼의 상태(눌렸으면 true)
) {
	// 폭탄의 상태
	static bool bombing=false;  // 폭격중인지 아닌지를 나타내는 플래그
	static float bx, by;        // 폭탄의 좌표
	static float tx, ty;        // 착탄점의 좌표

	// 폭격중이 아닐 때:
	// 버튼이 눌렸다면 폭격을 수행함.
	// 폭탄의 초기좌표와 착탄점의 좌표를 설정함.
	if (!bombing) {
		if (button) {
			bombing=true;
			bx=x; by=y;
			tx=sx; ty=sy;
		}
	}
	
	// 폭격중 일 때:
	// 폭탄을 이동시킴.
	// 폭탄이 착탄점에 도달하였다면 폭발시킴.
	// 폭발의 구체적인 처리는 Explode 함수에서 수행하도록 함.
	else {
		bx+=bvx; by+=bvy;
		if (bx==tx && by==ty) {
			Explode();
			bombing=false;
		}
	}
	
	// 메인 캐릭터와 조준을 그리기:
	// 구체적인 처리는 DrawMyShip関数とDrawScope 함수에서 수행하기로 함.
	// 조준과 지상물과의 접촉 판정 처리를 수행하면,
	// 조준의 가장자리를 점멸하는 것도 가능.
	DrawMyShip(x, y);
	DrawScope(sx, sy);

	// 폭격중인 경우에는 착탄점과 폭탄을 그림:
	// 구체적인 처리는 DrawTarget 함수와 DrawBomb 함수에서 수행하기로 함.
	if (bombing) {
		DrawTarget(tx, ty);
		DrawBomb(bx, by);
	}
}

