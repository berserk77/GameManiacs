void Shot();
void AimingShot(int id);
void DirectedShot(int dir);

void LockShot(
	bool button,     // 버튼 상태 (눌렸으면 true)
	int min_power,   // 에너지의 최소치
	int max_gauge,   // 연사 게이지의 최대치
	int enemy_id,    // 록 샷이 추적할 적기의 ID
	                 // (추적하지 않을 때는 음수값)
	float front_dir  // 메인 캐릭터의 정면을 향하는 방향
) {
	// 모은 에너지, 연사 게이지
	static int power=0, gauge=0;

	// 버튼을 누르고 있을 때:
	if (button) {
		
		// 에너지가 부족할 경우:
		// 에너지를 늘리고 연사 게이지를 최대값으로 한 후 
		// 샷을 발사. 구체적인 처리는 Shot 함수에서 수행하기로 함.
		if (power<min_power) {
			power++;
			gauge=max_gauge;
			Shot();
		}
	
		// 에너지가 충분할 경우:
		// 연사 게이지를 0으로 한 후 록 샷을 발사.
		else {
			gauge=0;
			
			// 록 샷을 발사:
			// 적기를 추적할 때는 조준탄을 쏨.
			// ("메인 캐릭터를 향하는 탄"과 같음)
			// 적기를 추적하지 않을 때는 메인 캐릭터의 정면을 향해 발사.
			// ("임의 방향으로 날아가는 탄"과 같음)
			// 각각 구체적인 처리는 AimingShot 함수와
			// DirectedShot 함수에서 수행하기로 함.
			if (enemy_id>=0) {
				AimingShot(enemy_id);
			} else {
				DirectedShot(front_dir);
			}
		}
	}
	
	// 버튼을 누르고 있지 않을 때:
	else {
		
		// 연사 게이지가 0보다 클 경우:
		// 보통 샷을 쏜 후, 연사 게이지를 1 감소시킴.
		if (gauge>0) {
			Shot();
			gauge--;
		}

		// 에너지를 0으로 함.
		power=0;
	}
}

