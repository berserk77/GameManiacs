void BigShot(int power);
void MaxShot();

void PowerShot(
	bool button,    // 버튼 상태 (눌렸으면 true)
	int min_power,  // 에너지 샷이 발사될 최소한의 파워
	int max_power   // 최대 파워
) {
	// 모은 에너지
	static int power=0;

	// 버튼을 누르고 있을 때:
	// 에너지를 모음
	if (button && power<max_power) power++;
	
	// 버튼을 누르고 있지 않을 때:
	// 모은 에너지가 0보다 크다면 샷을 발사하고 에너지를 0으로 되돌림.
	if (!button && power>0) {
		
		// 최대 파워일 때:
		// 특별한 샷을 발사.
		// 구체적인 처리는 MaxShot 함수에서 수행하기로 함.
		if (power==max_power) MaxShot(); else
		
		// 최소 파워 이상, 최대 파워 미만일 경우:
		// 모아둔 에너지에 해당하는 공격력의 에너지 샷을 발사함.
		// 구체적인 처리는 BigShot 함수에서 수행하기로 함.
		if (min_power<=power) BigShot(power);
		
		// 에너지를 0으로 되돌림.
		power=0;

	}
}

void PowerShotReleased(
	bool button,    // 버튼 상태 (눌렸으면 true)
	int min_power,  // 에너지 샷이 발사될 최소한의 파워
	int max_power   // 최대 파워
) {
	// 모은 에너지
	static int power=0;

	// 버튼을 누르고 있지 않을 때:
	// 에너지를 모음
	if (!button && power<max_power) power++;
	
	// 버튼을 누르고 있을 때:
	// 모은 에너지가 0보다 크다면 샷을 발사하고 에너지를 0으로 되돌림.
	if (button && power>0) {
		
		// 최대 파워일 때:
		// 특별한 샷을 발사.
		// 구체적인 처리는 MaxShot 함수에서 수행하기로 함.
		if (power==max_power) MaxShot(); else
		
		// 최소 파워 이상, 최대 파워 미만일 경우:
		// 모아둔 에너지에 해당하는 공격력의 에너지 샷을 발사함.
		// 구체적인 처리는 BigShot 함수에서 수행하기로 함.
		if (min_power<=power) BigShot(power);
		
		// 에너지를 0으로 되돌림.
		power=0;
	}
}

