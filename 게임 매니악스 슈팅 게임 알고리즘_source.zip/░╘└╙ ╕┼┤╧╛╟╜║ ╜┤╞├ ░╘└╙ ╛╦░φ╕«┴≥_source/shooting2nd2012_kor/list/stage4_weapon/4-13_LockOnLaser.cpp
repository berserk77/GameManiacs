// 적기를 나타내는 구조체
typedef struct {
	bool Locked;  // 고정된 상태인지 아닌지를 나타내는 플래그
	float X, Y;   // 좌표
} ENEMY_TYPE;
#define MAX_ENEMIES 100
static ENEMY_TYPE Enemy[MAX_ENEMIES];

bool Hit(float x, float y, ENEMY_TYPE& enemy);
void ShootLockOnLaser(ENEMY_TYPE& enemy);

// 록 온의 사용가능 횟수
static int AvailLocks=8;

// 록 온 레이저의 발사
void LockOnLaser(
	float sx, float sy,  // 조준의 좌표
	bool button          // 버튼의 상태(눌렸으면 true)
) {
	// 록 온의 사용가능 횟수가 1 이상일 경우:
	// 모든 적기와 조준과의 접촉 판정을 수행하여,
	// 조준과 겹쳐져 있는 적기에는 록 마크를 표시함.
	// 접촉 판정의 구체적인 처리는 Hit 함수에서 수행하기로 함.
	for (int i=0; AvailLocks>0 && i<MAX_ENEMIES; i++) {
		if (!Enemy[i].Locked && Hit(sx, sy, Enemy[i])) {
			Enemy[i].Locked=true;

			// 록 온의 사용 가능 횟수를 줄이기 :
			// 적기에 레이저가 명중하면 사용 가능 횟수를 늘려줌.
			AvailLocks--;
		}
	}

	// 버튼이 눌려졌을 경우:
	// 록 마크가 달려있는 모든 적기를 향해 레이저를 발사.
	// 발사의 구체적인 처리는 ShootLockOnLaser 함수에서 수행하기로 함.
	if (button) {
		for (int i=0; i<MAX_ENEMIES; i++) {
			if (Enemy[i].Locked) ShootLockOnLaser(Enemy[i]);
		}
	}
}

