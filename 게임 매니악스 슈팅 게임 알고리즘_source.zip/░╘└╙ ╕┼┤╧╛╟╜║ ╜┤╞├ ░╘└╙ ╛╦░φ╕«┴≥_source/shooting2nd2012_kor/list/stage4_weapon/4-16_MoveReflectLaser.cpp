// 레이저의 각 부분을 나타내는 구조체
typedef struct LASER_STRUCT {
	float X, Y;                 // 좌상좌표
	float W, H;                 // 폭과 높이
	float VX, VY;               // 속도
	float OldX, OldY;           // 이전 좌표
	struct LASER_STRUCT* Prec;  // 하나 앞 부분
	                            // (선두일 경우에는 NULL)
} LASER_TYPE;

// 레이저를 움직이는 함수
void MoveReflectLaser(
	LASER_TYPE* laser,         // 레이저의 한 부분
	float gx0[], float gy0[],  // 지형의 좌상좌표
	float gx1[], float gy1[],  // 지형의 우하좌표
	int num_ground             // 지형의 수
) {
	// 선두 부분인 경우:
	// 지형에 반사하는 샷의 처리와 같음.
	if (!laser->Prec) {

		// 지형과의 접촉 판정 처리:
		// 선두 부분을 수직 방향으로 진행시킨 좌표(X, Y+VY)에 대해서,
		// 지형에 접촉할지 아닐지를 판정함.
		// 지형에 닿을 경우에는 수직 방향의 속도를 역으로 하고
		// 루프를 빠져나옴.
		for (int i=0; i<num_ground; i++) {
			if (gx0[i]<laser->X+laser->W &&
				laser->X<gx1[i] && 
				gy0[i]<laser->Y+laser->W+laser->VY &&
				laser->Y+laser->VY<gy1[i]
			) {
				laser->VX=-laser->VX;
				break;
			}
		}

		// 선두 부분을 진행시키기
		laser->X+=laser->VX;
		laser->Y+=laser->VY;
	}
	
	// 선두 부분 이외의 경우:
	// 하나 앞 부분을 좇아감.
	// (하나 앞 부분의 이전 좌표로 이동)
	else {
		laser->X=laser->Prec->OldX;
		laser->Y=laser->Prec->OldY;
	}
}

