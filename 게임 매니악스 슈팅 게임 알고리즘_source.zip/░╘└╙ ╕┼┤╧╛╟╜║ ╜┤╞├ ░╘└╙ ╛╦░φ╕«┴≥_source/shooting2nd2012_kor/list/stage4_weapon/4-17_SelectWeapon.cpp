void DrawIcon(int id);
void FocusIcon(int id);

// 묵의 수
#define MAX_WEAPONS 5

// 무기를 전환하는 처리
void SelectWeapon(
	bool button  // 버튼의 상태(눌렸다면 true)
) {
	static int weapon_id=0;         // 현재 선택중인 무기의 번호
	static bool prev_button=false;  // 이전의 버튼 상태
	
	// 무기를 바꾸기:
	// 이전에 버튼을 누르지 않았다가 이번에 눌렀다면
	// 무기를 바꿈.
	if (!prev_button && button) {
		weapon_id=(weapon_id+1)%MAX_WEAPONS;
	}
	
	// 무기 아이콘을 표시하기:
	// 모든 아이콘을 표시하고 선택중인 아이콘은 돋보이게 함.
	// 표시를 하는 구체적인 처리는 DrawIcon 함수와 FocusIcon 함수에서
	// 수행하기로 함.
	for (int i=0; i<MAX_WEAPONS; i++) DrawIcon(i);
	FocusIcon(weapon_id);

	// 현재 버튼상태를 저장해 둠.
	prev_button=button;
}


