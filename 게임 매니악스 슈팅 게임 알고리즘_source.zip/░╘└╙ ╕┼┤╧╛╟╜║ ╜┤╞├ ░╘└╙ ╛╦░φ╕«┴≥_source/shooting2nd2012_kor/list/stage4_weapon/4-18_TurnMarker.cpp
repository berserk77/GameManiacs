#include <math.h>

void DirectedShot(float x, float y, float dir);

void TurnMarker(
	float& x, float& y,     // 메인 캐릭터의 좌표
	float speed,            // 메인 캐릭터의 속도
	bool left, bool right,  // 스틱의 상태 (좌우방향)
	bool up, bool down,     // 스틱의 상태 (상하방향)
	bool turn_button,       // 선회 버튼의 상태
	bool shot_button        // 샷 버튼의 상태
) {
	static bool turning;        // 선회중이면 true
	static float mx, my;        // 턴 마커의 좌표
	static float rad=M_PI*3/2;  // 선회 각도(M_PI는 원주율을 나타냄)
	static float d=10;          // 메인 캐릭터와 턴 마커의 거리
	
	// 선회할 경우:
	// 턴 마커의 좌표를 게산하기.
	if (!turning && turn_button) {
		turning=true;
		mx=x-d*cos(rad);
		my=y-d*sin(rad);
	}
	
	// 선회 종료
	if (!turn_button) turning=false;
	
	// 메인 캐릭터의 이동
	if (up   ) y-=speed;
	if (down ) y+=speed;
	if (left ) x-=speed;
	if (right) x+=speed;
	
	// 선회중이면 선회각도를 계산하기
	if (turning) rad=atan2(y-my, x-mx);
	
	// 샷의 발사:
	// 메인 캐릭터가 향하는 방향으로 샷을 발사.
	// 발사 방향은 rad의 반대방향(180도 회전)
	// 발사의 구체적인 처리는 DirectedShot 함수에서 수행하기로 함.
	if (shot_button) DirectedShot(x, y, rad+M_PI);
}

