void ComShot(int id);

//============================================================== (1)
// 스틱과 버튼의 상태를 나타내는 플래그：
// 2개 이상의 플래그를 조합할 수도 있음.
// 예를 들어 "왼쪽 위"는 
// "상"과 "좌"의 조합 (UP|LEFT)로 나타냄.
#define NONE     0  // 초기상태
#define NEUTRAL  1  // 중립
#define UP       2  // 상
#define DOWN     4  // 하
#define LEFT     8  // 좌
#define RIGHT   16  // 우
#define BUTTON  32  // 버튼

// 저장할 입력 내역의 갯수, 입력 내역 저장용 배열
#define NUM_HISTORY 30
static int History[NUM_HISTORY];

// 커맨드
typedef struct {
	int Length;              // 커맨드의 길이
	int Limit;               // 입력 제한 시간
	int Input[NUM_HISTORY];  // 입력 내용
} COMMAND_TYPE;
#define NUM_COMMAND 2
COMMAND_TYPE Command[NUM_COMMAND];

//============================================================== (2)
// 입력 이력과 커맨드의 초기화
void InitCommandShot()
{
	// 입력 이력의 초기화
	for (int i=0; i<NUM_HISTORY; i++) History[i]=NONE;

	// 커맨드 1 (파동권 커맨드)
	Command[0].Length=4;
	Command[0].Limit=30;
	Command[0].Input[0]=DOWN;
	Command[0].Input[1]=DOWN|RIGHT;
	Command[0].Input[2]=RIGHT;
	Command[0].Input[3]=BUTTON;

	// 커맨드 2 (승룡권 커맨드)
	Command[1].Length=4;
	Command[1].Limit=30;
	Command[1].Input[0]=RIGHT;
	Command[1].Input[1]=DOWN;
	Command[1].Input[2]=DOWN|RIGHT;
	Command[1].Input[3]=BUTTON;
}

//============================================================== (3)
// 커맨드 샷의 판정을 수행하는 함수
void CommandShot(
	bool up, bool down,     // 스틱 상태 (상하좌우)
	bool left, bool right,  
	bool button             // 버튼 상태 (눌렸으면 true)
) {
	// 입력 내역의 기록 위치
	static int index=0;
	
	// 입력 내역을 기록하기
	History[index]=
		(up?UP:0)|(down?DOWN:0)|
		(left?LEFT:0)|(right?RIGHT:0)|
		(button?BUTTON:0);

	// 커맨드가 입력되었는지 판정하기
	int c, j, i;
	for (c=0; c<NUM_COMMAND; c++) {
		for (i=0, j=Command[c].Length-1; j>=0; j--) {
			for (; i<Command[c].Limit; i++) {
				if (History[(index-i+NUM_HISTORY)
					%NUM_HISTORY]==Command[c].Input[j]) break;
			}
			if (i==Command[c].Limit) break;
		}
		
		// 커맨드가 입력된 것이 확인되었음:
		// 커맨드 샷을 발사하고 입력 내역을 지움.
		// 구체적인 처리는 ComShot 함수에서 수행하기로 함.
		if (j==-1) {
			ComShot(j);
			for (i=0; i<NUM_HISTORY; i++) History[i]=NONE;
		}
	}
	
	// 기록 위치를 갱신하기
	index=(index+1)%NUM_HISTORY;
}

