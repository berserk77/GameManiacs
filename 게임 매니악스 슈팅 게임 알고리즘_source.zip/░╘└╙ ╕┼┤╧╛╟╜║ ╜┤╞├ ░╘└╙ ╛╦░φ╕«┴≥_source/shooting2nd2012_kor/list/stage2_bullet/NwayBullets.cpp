#include <math.h>

void RotateVelocity(
	float theta,           // 회전 각도
	float vx0, float vy0,  // 원래 속도
	float& vx, float& vy   // 회전후의 속도
) {
	// theta를 라디안으로 변환하여 cos과 sin값을 구하기:
	// M_PI는 원주율.
	float rad=M_PI/180*theta;
	float c=cos(rad), s=sin(rad);

	// 속도벡터 (vx0,vy0)를 회전시킨 (vx,vy)를 구하기
	vx=vx0*c-vy0*s;
	vy=vx0*s+vy0*c;
}

void InitNWayBullets(
	float vx0, float vy0,    // 중심이 되는 탄의 속도
	float theta,             // 탄과 탄사이의 각도
	int n,                   // 탄의 갯수
	float vx[], float vy[]   // n-way탄의 속도
) {
	// 탄과 탄 사이의 각도를 라디안으로 변환하기
	float rad_step=M_PI/180*theta;
	
	// 가장자리의 탄과 중심 부분의 탄의 각도를 계산하기
	float rad=n%2 ? -n/2*rad_step : (-n/2+0.5)*rad_step;

	// n개의 탄의 속도를 계산하기
	for (int i=0; i<n; i++, rad+=rad_step) {
		
		// (vx[i],vy[i])를 구하기:
		// 속도 벡터 (vx0,vy0)를 rad만큼 회전시키기.
		float c=cos(rad), s=sin(rad);
		vx[i]=vx0*c-vy0*s;
		vy[i]=vx0*s+vy0*c;
	}
}

