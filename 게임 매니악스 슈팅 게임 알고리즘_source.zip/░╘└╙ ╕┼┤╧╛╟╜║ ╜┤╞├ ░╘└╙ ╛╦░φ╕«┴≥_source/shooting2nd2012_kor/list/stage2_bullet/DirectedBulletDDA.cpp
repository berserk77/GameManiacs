#include <math.h>

void InitDirectedBulletDDA(
	int theta,         // 발사 각도
	int ex, int ey,    // 적의 좌표
	int& x, int& y,    // 탄의 좌표
	int& vx, int& vy,  // 탄의 이동방향
	int& dx, int& dy,  // X방향과 Y방향의 차이
	int& diff          // 오차
) {
	// 가상적인 메인 캐릭터를 멀리 배치하기:
	// M_PI는 원주율
	int mx=cos(M_PI/180*theta)*1000;
	int my=sin(M_PI/180*theta)*1000;

	// 이후는 DDA를 사용한 조준탄 처리와 동일함

	// 탄의 좌표를 설정하기
	x=ex; y=ey;

	// 탄의 이동방향(vx,vy)을 구하기: 값은 1 혹은 -1
	vx=mx>ex?1:-1;
	vy=my>ey?1:-1;

	// 목표에 대한 X방향과 Y방향의 차이의 절대치(dx, dy)를 구하기
	dx=mx>=ex?mx-ex:ex-mx;
	dy=my>=ey?my-ey:ey-my;

	// 오차diff : dx>=dy일 때는 dx/2, dx<dy일 때는 dy/2로 설정함
	diff=dx>=dy?dx/2:dy/2;
}

