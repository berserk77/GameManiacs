#include <math.h>

// 메인 캐릭터의 위치를 저장하는 테이블
int mpos[360][2];

// 테이블을 작성하기:
// M_PI는 원주율
void MakeTable() {
	for (int i=0; i<360; i++) {
		mpos[i][0]=cos(M_PI/180*i)*1000;
		mpos[i][1]=sin(M_PI/180*i)*1000;
	}
}

void InitDirectedBulletDDA2(
	int theta,         // 발사각도
	int ex, int ey,    // 적의 좌표
	int& x, int& y,    // 탄의 좌료
	int& vx, int& vy,  // 탄의 이동방향
	int& dx, int& dy,  // X방향과 Y방향의 차이
	int& diff          // 오차
) {
	// 가상적인 메인 캐릭터의 위치를 테이블에서 읽어옴
	int dir=(theta%360+360)%360;
	int mx=mpos[dir][0];
	int my=mpos[dir][1];

	// 이후는 DDA를 사용하여 메인 캐릭터 방향으로 탄을 보내는 처리와 같음

	// 탄의 좌표를 설정하기
	x=ex; y=ey;

	// 탄의 이동방향(vx,vy)을 구하기: 값은 1 혹은 -1
	vx=mx>ex?1:-1;
	vy=my>ey?1:-1;

	// 목표에 대한 X방향과 Y방향의 차이의 절대치(dx, dy)를 구하기
	dx=mx>=ex?mx-ex:ex-mx;
	dy=my>=ey?my-ey:ey-my;

	// 오차diff : dx>=dy일 때는 dx/2, dx<dy일 때는 dy/2로 설정함
	diff=dx>=dy?dx/2:dy/2;
}

