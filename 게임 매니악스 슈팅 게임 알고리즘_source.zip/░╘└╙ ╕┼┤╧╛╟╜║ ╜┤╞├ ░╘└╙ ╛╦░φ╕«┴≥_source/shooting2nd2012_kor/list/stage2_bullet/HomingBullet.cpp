#include <math.h>

void MoveHomingBullet(
	float& x, float& y,    // 탄의 좌표
	float& vx, float& vy,  // 탄의 속도벡터
	float mx, float my,    // 메인 캐릭터의 좌표
	float speed,           // 탄의 속도
	float theta            // 선회 각도의 상한치
) {
	// 탄의 원래 속도벡터를 저장
	float vx0=vx, vy0=vy;

	// 메인 캐릭터 방향으로의 속도 벡터(vx1, vy1)를 구하기
	float vx1, vy1;
	float d=sqrt((mx-x)*(mx-x)+(my-y)*(my-y));
	if (d) {
		vx1=(mx-x)/d*speed;
		vy1=(my-y)/d*speed;
	} else {
		vx1=0;
		vy1=speed;
	}

	// 시계방향으로 선회할 때의 상한 각도에 해당하는 속도벡터(vx2, vy2)를 구하기:
	// M_PI는 원주율
	float rad=M_PI/180*theta;
	float vx2=cos(rad)*vx0-sin(rad)*vy0;
	float vy2=sin(rad)*vx0+cos(rad)*vy0;

	// 메인 캐릭터 방향으로 선회할 지 제한각도만큼만 선회할 지 정하기
	if (vx0*vx1+vy0*vy1>=vx0*vx2+vy0*vy2) {
		
		// 메인 캐릭터가 선회 가능한 범위 내에 있을 경우:
		// 메인 캐릭터 방향으로 선회함
		vx=vx1;
		vy=vy1;

	} else {

		// 메인 캐릭터가 선회 가능한 범위 밖에 있을 경우:
		// 시계 반대방향으로 선회할 때의 상한 각도에 해당하는 속도벡터(vx3, vy3)를 구하기
		float vx3= cos(rad)*vx0+sin(rad)*vy0;
		float vy3=-sin(rad)*vx0+cos(rad)*vy0;
		
		// 탄에서 메인 캐릭터까지의 상대위치벡터(px, py)를 구하기
		float px=mx-x, py=my-y;
		
		// 시계방향으로 선회할 지 시계 반대방향으로 선회할 지 정하기
		if (px*vx2+py*vy2>=px*vx3+py*vy3) {

			// 시계방향일 경우
			vx=vx2;
			vy=vy2;

		} else {

			// 시계 반대방향일 경우
			vx=vx3;
			vy=vy3;

		}
	}

	// 탄의 좌표(x, y)를 갱신하여 탄을 이동시킴
	x+=vx;
	y+=vy;
}

