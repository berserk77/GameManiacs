#include <stdio.h>

// 미사일의 각 부분을 나타내는 구조체
typedef struct MISSILE_STRUCT {
	float X, Y;                   // 좌표
	float VX, VY;                 // 속도
	float OldX, OldY;             // 이전 좌표
	float Angle;                  // 회전 각도
	float OldAngle;               // 이전 회전 각도
	struct MISSILE_STRUCT* Prec;  // 하나 앞 부분을 가리키는 포인터
	                              // (선두부분일 경우는 NULL)
	bool IsMissile;               // 미사일인지 아닌지
	                              // (true라면 미사일,
	                              //  false라면 연기)
} MISSILE_TYPE;

MISSILE_TYPE* NewMissileType();

// 미사일의 발사
void ShootMissile(
	float x, float y,   // 발사지점의 좌표
	int length          // 연기의 길이(역자주: 원저에는 레이저의 길이라고 되어있으나 오타인 듯)
) {
	MISSILE_TYPE* missile;    // 미사일의 구조체를 가리키는 포인터
	MISSILE_TYPE* prec=NULL;  // 하나 앞 부분을 가리키는 포인터
	
	// 미사일의 각 부분을 만들기:
	// 미사일의 구조체를 생성하여 좌표를 초기화하기
	// 구조체를 생성하는 구체적인 처리는 NewMissileType함수에서 수행한다고 가정함
	for (int i=0; i<length; i++, prec=missile) {
		missile=NewMissileType();
		missile->X=missile->OldX=x;
		missile->Y=missile->OldY=y;
		missile->Angle=missile->OldAngle=0;

		// 연기 부분은 하나 앞의 부분을 참조하도록 함
		// 선두 부분을 참조했을 때는 NULL이 반환됨
		missile->Prec=prec;

		// 선두 부분은 미사일, 다른 부분은 연기임을 가리키는 플래그
		missile->IsMissile=(i==0);
	}
}

