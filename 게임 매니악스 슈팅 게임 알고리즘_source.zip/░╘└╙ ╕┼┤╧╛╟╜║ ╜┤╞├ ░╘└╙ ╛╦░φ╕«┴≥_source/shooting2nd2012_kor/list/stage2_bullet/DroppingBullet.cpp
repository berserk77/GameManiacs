void MoveDroppingBullet(
	float& x, float& y,   // 탄의 좌표
	float accel,          // 가속도
	float& vx, float& vy  // 속도 벡터의 X성분과 Y성분
) {
	// 속도를 갱신하기:
	// X성분은 가만히 두고 Y성분만 변화시킴
	vy+=accel;

	// 좌표를 갱신하기
	x+=vx; y+=vy;
}
