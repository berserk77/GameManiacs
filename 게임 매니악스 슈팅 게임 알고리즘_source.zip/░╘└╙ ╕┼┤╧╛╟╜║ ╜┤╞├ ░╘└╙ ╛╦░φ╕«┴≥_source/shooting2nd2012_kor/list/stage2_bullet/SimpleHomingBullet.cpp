#include <math.h>

void MoveSimpleHomingBullet(
	float& x, float& y,  // 탄의 좌표
	float mx, float my,  // 메인 캐릭터의 좌표
	float speed          // 탄의 속도
) {
	// 목표까지의 거리 d를 구하기
	float d=sqrt((mx-x)*(mx-x)+(my-y)*(my-y));

	// 탄의 속도벡터(vx, vy)를 구하기:
	// 속도가 일정한 값(speed)가 되도록 함
	// 목표까지의 거리 d가 0일 때는 속도 벡터를 화면 아랫쪽으로 함
	float vx, vy;
	if (d) {
		vx=(mx-x)/d*speed;
		vy=(my-y)/d*speed;
	} else {
		vx=0;
		vy=speed;
	}

	// 탄의 좌표(x, y)를 갱신하여 탄을 이동시킴
	x+=vx;
	y+=vy;
}

