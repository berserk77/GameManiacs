void InitAimingBulletDDA(
	int mx, int my,    // 메인 캐릭터의 위치
	int ex, int ey,    // 적의 좌표
	int& x, int& y,    // 탄의 좌표
	int& vx, int& vy,  // 탄의 이동방향
	int& dx, int& dy,  // X방향과 Y방향의 차이
	int& diff          // 오차
) {
	// 탄의 좌표를 설정하기
	x=ex; y=ey;

	// 탄의 이동방향(vx,vy)을 구하기: 값은 1 혹은 -1
	vx=mx>ex?1:-1;
	vy=my>ey?1:-1;

	// 목표에 대한 X방향과 Y방향의 차이의 절대치(dx, dy)를 구하기
	dx=mx>=ex?mx-ex:ex-mx;
	dy=my>=ey?my-ey:ey-my;

	// 오차diff : dx>=dy일 때는 dx/2, dx<dy일 때는 dy/2로 설정함
	diff=dx>=dy?dx/2:dy/2;
}

void MoveAimingBulletDDA(
	int& x, int& y,  // 탄의 좌표
	int vx, int vy,  // 탄의 이동방향
	int dx, int dy,  // X방향과 Y방향의 차이
	int& diff,       // 오차
	int speed        // 탄의 속도
) {
	// X방향으로의 이동거리가 길 때
	if (dx>=dy) {
		for (int i=0; i<speed; i++) {

			// X방향으로는 매번 이동시킴
			x+=vx;
			
			// Y방향으로는 오차가 누적되었을 경우에만 이동시킴
			diff+=dy;
			if (diff>=dx) {
				diff-=dx;
				y+=vy;
			}
		}
	} 

	// Y방향으로의 이동거리가 길 때
	else {
		for (int i=0; i<speed; i++) {

			// Y방향으로는 매번 이동시킴
			y+=vy;

			// X방향으로는 오차가 누적되었을 경우에만 이동시킴
			diff+=dx;
			if (diff>=dy) {
				diff-=dy;
				x+=vx;
			}
		}
	}
}

