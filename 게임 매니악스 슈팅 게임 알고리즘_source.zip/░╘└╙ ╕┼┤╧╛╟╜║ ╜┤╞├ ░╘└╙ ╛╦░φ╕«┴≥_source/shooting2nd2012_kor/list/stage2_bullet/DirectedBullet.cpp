#include <math.h>

void InitDirectedBullet(
	float ex, float ey,    // 적의 좌표
	float& x, float& y,    // 탄의 좌표
	float& vx, float& vy,  // 탄의 속도벡터
	float speed,           // 탄의 속도
	float theta            // 발사각도
) {
	// 탄의 좌표를 설정하기
	x=ex; y=ey;

	// speed의 속도로 각도 theta 방향으로 날아가는 탄의 속도벡터(vx,vy)를 구하기:
	// M_PI는 원주율
	vx=cos(M_PI/180*theta)*speed;
	vy=sin(M_PI/180*theta)*speed;
}

void MoveDirectedBullet(
	float& x, float& y,  // 탄의 좌표
	float vx, float vy   // 탄의 속도벡터
) {
	// 탄의 좌표(x,y)에 속도벡터(vx,vy)를 더하기
	x+=vx;
	y+=vy;
}

