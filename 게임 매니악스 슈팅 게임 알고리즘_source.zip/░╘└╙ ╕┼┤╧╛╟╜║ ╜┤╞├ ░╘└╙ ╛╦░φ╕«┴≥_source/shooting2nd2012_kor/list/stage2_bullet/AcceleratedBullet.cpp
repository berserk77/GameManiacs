void MoveAcceleratedBullet(
	float speed,          // 탄의 속도
	float accel,          // 가속도
	float& vx, float& vy  // 속도벡터의 X성분과 Y성분
) {
	// 속도벡터의 X,Y 성분을 이전 속도로 나누기
	if (speed!=0) {
		vx/=speed; vy/=speed;
	}

	// 속도를 갱신하기
	speed+=accel;

	// 속도벡터의 X,Y성분에 새로운 속도를 곱하기
	vx*=speed; vy*=speed;
}

