void Draw(int x, int y);

void InitAimingBulletFP(
	int mx, int my,    // 메인 캐릭터의 위치
	int ex, int ey,    // 적의 좌표
	int& x, int& y,    // 탄의 좌표
	int& vx, int& vy,  // 탄의 속도벡터
	int speed          // 탄의 속도
) {
	// 탄의 좌표를 설정하기
	x=ex; y=ey;

	// 목표에 대한 X방향과 Y방향의 차이의 절대값(dx, dy)를 구하기
	int dx=mx>=ex?mx-ex:ex-mx;
	int dy=my>=ey?my-ey:ey-my;

	// X방향과 Y방향의 차이중 보다 긴 쪽을 거리 d로 둠
	int d=dx>=dy?dx:dy;

	// 속도벡터(vx,vy)를 구하기
	vx=(mx-ex)*speed/d;
	vy=(my-ey)*speed/d;
}

void MoveAimingBulletFP(
	int& x, int& y,  // 탄의 좌표
	int vx, int vy   // 탄의 속도
) {
	// 탄의 좌표(x, y)에 속도벡터(vx,vy)를 더하기
	x+=vx;
	y+=vy;

	// 탄을 그리기:
	// 화면에 탄을 그릴 때는 좌표를 (x>>8, y>>8)로 지정함
	// 탄을 그리는 구체적인 처리는 Draw함수에서 수행하기로 가정함
	Draw(x>>8, y>>8);
}

