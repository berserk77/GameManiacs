#include <math.h>

void InitAimingBullet(
	float mx, float my,   // 메인 캐릭터의 위치
	float ex, float ey,   // 적의 좌표
	float speed,          // 탄의 속도
	float& x, float& y,   // 탄의 좌표
	float& vx, float& vy  // 탄의 속도
) {
	// 탄의 좌표를 설정하기
	x=ex; y=ey;

	// 목표까지의 거리 d를 구하기
	float d=sqrt((mx-ex)*(mx-ex)+(my-ey)*(my-ey));

	// 속도가 일정한 값(speed)이 되도록 속도벡터를 구하기:
	// 목표까지의 거리 d가 0일 때는 아랫쪽으로 발사함
	if (d) {
		vx=(mx-ex)/d*speed;
		vy=(my-ey)/d*speed;
	} else {
		vx=0;
		vy=speed;
	}
}

void MoveAimingBullet(
	float& x, float& y,  // 탄의 좌표
	float vx, float vy   // 탄의 속도
) {
	// 탄의 좌표(x,y)에 속도를 더해줌
	x+=vx;
	y+=vy;
}

