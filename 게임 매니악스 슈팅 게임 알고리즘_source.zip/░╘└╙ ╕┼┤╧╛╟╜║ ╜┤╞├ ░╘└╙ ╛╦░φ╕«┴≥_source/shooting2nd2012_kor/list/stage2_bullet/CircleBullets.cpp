#include <math.h>

void InitCircleBullets(
	int n,                   // 탄의 갯수
	float speed,             // 탄의 속도
	bool odd,                // 홀수 패턴일 때 참
	float vx[], float vy[]   // 원형탄의 속도벡터
) {
	// 탄과 탄 사이의 각도를 계산하기
	float rad_step=M_PI*2/n;

	// 최초의 탄의 각도를 계산하기:
	// 홀수 패턴일 때는 rad_step/2만큼 틀어줌.
	float rad=odd ? rad_step/2 : 0;

	// n개의 탄의 속도벡터를 구하기:
	// speed의 속도로 각도 rad 방향으로 날아가는 탄의 속도벡터를 구하기
	// 원형탄을 날리는 처리를 응용한 것
	for (int i=0; i<n; i++, rad+=rad_step) {
		vx[i]=cos(rad)*speed;
		vy[i]=sin(rad)*speed;
	}
}

