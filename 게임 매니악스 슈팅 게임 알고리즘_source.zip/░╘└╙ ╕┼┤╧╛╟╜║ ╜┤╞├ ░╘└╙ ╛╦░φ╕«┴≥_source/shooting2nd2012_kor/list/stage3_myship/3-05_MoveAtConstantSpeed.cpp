#include <math.h>

void MoveAtConstantSpeed(
	float& x, float& y,    // 메인 캐릭터의 좌표(X방향, Y방향)
	float speed,           // 메인 캐릭터의 속도
	bool up, bool down,    // 상하 방향으로의 스틱 입력
	bool left, bool right  // 좌우 방향으로의 스틱 입력
) {
	// 대각선으로 이동할 때의 속도:
	// 상하좌우의 약 0.7배로 조절함.
	float s=speed/sqrt(2);

	// 대각선 이동
	if (up   && left ) x-=s, y-=s; else
	if (up   && right) x+=s, y-=s; else
	if (down && left ) x-=s, y+=s; else
	if (down && right) x+=s, y+=s; else
	
	// 상하좌우 이동
	if (up    && !down ) y-=speed; else
	if (down  && !up   ) y+=speed; else
	if (left  && !right) x-=speed; else
	if (right && !left ) x+=speed;
}

