void Walk();
void Fly();

// 메인 캐릭터의 형태(보행, 비행)
typedef enum {
	WALKING, FLYING
} MYSHIP_FORM;

// 메인 캐릭터의 변신
void Transform(
	bool button  // 변신 버튼의 입력
) {
	static MYSHIP_FORM formation=WALKING;  // 메인 캐릭터의 형태
	static bool prev_button=false;         // 이전의 버튼 입력
	
	// 변신:
	// 변신 버튼이 입력되었다면 변신을 수행함.
	if (!prev_button && button) {
		if (formation==WALKING) formation=FLYING;
			else formation=WALKING;
	}
	prev_button=button;
	
	// 형태에 따라 움직임을 바꾸어줌:
	// 구체적인 처리는 Walk，Fly함수에서 수행하기로 가정함.
	if (formation==WALKING) Walk(); else Fly();
}

