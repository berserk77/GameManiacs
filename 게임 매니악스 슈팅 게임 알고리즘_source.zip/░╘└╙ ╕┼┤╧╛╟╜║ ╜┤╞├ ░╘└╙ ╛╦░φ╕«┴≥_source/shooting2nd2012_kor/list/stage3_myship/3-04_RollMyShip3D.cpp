void Draw(int roll);

void RollMyShip3D(
	int& roll,             // 롤의 각도
	bool left, bool right  // 좌우방향으로의 스틱 입력
) {
	// 스틱으로 왼쪽을 입력했을 경우:
	// -60<roll이라면 roll을 -3해줌
	if (left && -60<roll) roll-=3;

	// 스틱으로 오른쪽을 입력했을 경우:
	// roll<60이라면 roll을 +3해줌
	if (right && roll<60) roll+=3;

	// 스틱으로 왼쪽도 오른쪽도 입력하지 않았을 경우:
	// roll이 0에 가까워지도록 해 줌
	if (!left && !right) {
		if (roll<0) roll+=3; else
		if (0<roll) roll-=3;
	}

	// roll의 값에 따라 메인 캐릭터를 회전시켜 표시하기:
	// 구체적인 처리는 Draw함수에서 수행한다고 가정함
	Draw(roll);
}

