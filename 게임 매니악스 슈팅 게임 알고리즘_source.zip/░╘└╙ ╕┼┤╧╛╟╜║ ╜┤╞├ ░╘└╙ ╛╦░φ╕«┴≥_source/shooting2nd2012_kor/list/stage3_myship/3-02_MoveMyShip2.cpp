void MoveMyShip2(
	float& x, float& y,    // 메인 캐릭터의 좌표(X방향, Y방향)
	float speed,           // 메인 캐릭터의 속도
	float x0, float y0,    // 메인 캐릭터의 좌상좌표
	float x1, float y1,    // 메인 캐릭터의 우하좌표
	float sx0, float sy0,  // 이동 가능한 테두리의 좌상좌표
	float sx1, float sy1,  // 이동 가능한 테두리의 우하좌표
	bool up, bool down,    // 상하 방향으로의 스틱 입력
	bool left, bool right  // 우하 방향으로의 스틱 입력
) {
	if (up    && sy0<=y0) y-=speed;
	if (down  && y1<=sy1) y+=speed;
	if (left  && sx0<=x0) x-=speed;
	if (right && x1<=sx1) x+=speed;
}

