void Warp(
	float& x, float& y,    // 메인 캐릭터의 좌표
	float speed,           // 메인 캐릭터의 이동속도
	float warp_dist,       // 워프의 이동거리
	bool up, bool down,    // 스틱 입력(상하)
	bool left, bool right  // 스틱 입력(좌우)
) {
	static bool 
		up0=false, down0=false,     // 이전의 스틱 입력
		left0=false, right0=false,  // (상하, 좌우)
		released=true;              // 무입력 상태 플래그
	static int time=0;              // 입력의 제한시간

	// 스틱이 입력 되었을 때
	if (up || down || left || right) {
		
		// 워프 처리를 해야할 경우:
		// 입력 시간 이내에 특정 방향으로 스틱을 입력한 후, 잠시 스틱을 제자리로 되돌렸다가
		// 다시 같은 방향으로 스틱 입력을 했을 때
		if (released && time>0 &&
			up==up0 && down==down0 &&
			left==left0 && right==right0
		) {
			if (up   ) y-=warp_dist;
			if (down ) y+=warp_dist;
			if (left ) x-=warp_dist;
			if (right) x+=warp_dist;
		}
		
		// 워프 처리를 하지 않을 경우 
		// 스틱의 이전 상태가 무입력 상태가 아니거나, 제한시간이 지났거나
		// 이전과 다른 방향으로 스틱 입력이 되었을 때.
		// 방향을 기록하고, 제한시간을 설정함.
		else {
			up0=up; down0=down;
			left0=left; right0=right;
			time=10;
			
			// 그냥 이동시킴
			if (up   ) y-=speed;
			if (down ) y+=speed;
			if (left ) x-=speed;
			if (right) x+=speed;
		}

		released=false;
	}
	
	// 스틱이 무입력 상태가 되었을 때
	else released=true;
	
	// 시간을 줄여줌
	if (time>0) time--;
}

