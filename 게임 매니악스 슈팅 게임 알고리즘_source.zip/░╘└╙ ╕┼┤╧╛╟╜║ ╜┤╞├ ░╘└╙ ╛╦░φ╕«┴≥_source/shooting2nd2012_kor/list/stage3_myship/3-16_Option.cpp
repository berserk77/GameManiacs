void DrawOption(float x, float y);

// 옵션의 초기화
void InitOption(
	float x, float y,        // 메인 캐릭터의 좌표 (X방향, Y방향)
	float ox[], float oy[],  // 메인 캐릭터의 이전 좌표 (배열)
	int length               // 이전 좌표의 갯수 (배열의 길이)
) {
	// 배열의 모든 요소를 메인 캐릭터의 좌표로 초기화하기
	for (int i=0; i<length; i++) {
		ox[i]=x; oy[i]=y;
	}
}

// 옵션의 이동
void MoveOption(
	float x, float y,        // 메인 캐릭터의 좌표 (X방향, Y방향)
	float ox[], float oy[],  // 메인 캐릭터의 이전 좌표 (배열)
	int length,              // 이전 좌표의 갯수 (배열의 길이)
	int& index,              // 좌표의 저장 위치 (배열상의 위치)
	int opt_count,           // 옵션의 갯수
	int opt_interval         // 옵션의 간격 (배열 상의 간격)
) {
	// 옵션을 그리기:
	// DrawOption은 옵션을 그리는 함수라고 가정함
	for (int c=0, i=index; c<opt_count; c++) {
		i=(i-opt_interval+length)%length;
		DrawOption(ox[i], oy[i]);
	}
	
	// 메인 캐릭터의 좌표를 저장하고 좌표의 저장 위치를 갱신하기
	ox[index]=x;
	oy[index]=y;
	index=(index+1)%length;
}

