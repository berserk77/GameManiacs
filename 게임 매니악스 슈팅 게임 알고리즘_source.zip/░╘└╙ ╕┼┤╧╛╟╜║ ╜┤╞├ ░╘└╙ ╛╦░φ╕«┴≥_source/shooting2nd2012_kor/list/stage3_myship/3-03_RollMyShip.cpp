typedef enum {
	LEFT_BIG_ROLL, LEFT_SMALL_ROLL,
	CENTER,
	RIGHT_SMALL_ROLL, RIGHT_BIG_ROLL
} ROLL;

void Draw(ROLL roll);

void RollMyShip(
	int& roll,             // 롤의 각도
	bool left, bool right  // 좌우방향으로의 스틱 입력
) {
	// 스틱으로 왼쪽을 입력했을 경우:
	// -20<roll이라면 roll을 -1해줌
	if (left && -20<roll) roll--;

	// 스틱으로 오른쪽을 입력했을 경우:
	// roll<20이라면 roll을 +1해줌
	if (right && roll<20) roll++;

	// 스틱으로 왼쪽도 오른쪽도 입력하지 않았을 경우:
	// roll이 0에 가까워지도록 해줌
	if (!left && !right) {
		if (roll<0) roll++; else
		if (0<roll) roll--;
	}

	// roll의 값에 따라 다른 패턴을 표시하기：
	// 패턴 표시의 구체적인 처리는 Draw함수에서 수행한다고 가정함
	if (-20<=roll && roll<-15) Draw(LEFT_BIG_ROLL);    else
	if (-15<=roll && roll< -5) Draw(LEFT_SMALL_ROLL);  else
	if ( -5<=roll && roll<= 5) Draw(CENTER);           else
	if (  5< roll && roll<=15) Draw(RIGHT_SMALL_ROLL); else
	if ( 15< roll && roll<=20) Draw(RIGHT_BIG_ROLL);
}

