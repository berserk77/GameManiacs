void DeleteBullet(int id);
void DamageEnemy(int id);
void DeleteBarrier();

void Barrier1(
	float x0, float y0,        // 보호막의 접촉 판정 영역
	float x1, float y1,        // (좌상좌표, 우하좌표)
	float bx0[], float by0[],  // 탄의 접촉 판정 영역
	float bx1[], float by1[],  // (좌상좌표, 우하좌표)
	int num_bullet,            // 탄의 갯수
	float ex0[], float ey0[],  // 적기의 접촉 판정 영역
	float ex1[], float ey1[],  // (좌상좌표, 우하좌표)
	int num_enemy,             // 적기의 갯수
	int& damage,               // 보호막에 축적된 피해
	int max_damage             // 보호막의 피해 한계치
) {
	// 보호막과 탄과의 접촉 판정 처리:
	// 탄과 접촉했다면 탄을 지우고 보호막의 피해치를 늘림
	// 탄을 지우는 구체적인 처리는 DeleteBullet함수에서 수행한다고 가정함
	for (int i=0; i<num_bullet && damage<max_damage; i++) {
		if (bx0[i]<x1 && x0<bx1[i] && 
			by0[i]<y1 && y0<by1[i]) {
			DeleteBullet(i);
			damage++;
		}
	}

	// 보호막과 적기의 접촉 판정 처리:
	// 적기와 접촉했다면 적기에게 피해를 입히고
	// 보호막의 피해치도 늘려줌
	// 적기에 피해를 주는 구체적인 처리는 
	// DamageEnemy함수에서 수행한다고 가정함
	for (int i=0; i<num_enemy && damage<max_damage; i++) {
		if (ex0[i]<x1 && x0<ex1[i] && 
			ey0[i]<y1 && y0<ey1[i]) {
			DamageEnemy(i);
			damage++;
		}
	}
	
	// 피해치가 한계치를 초과했을 경우:
	// 보호막을 제거함
	// 제거하는 구체적인 처리는 DeleteBarrier함수에서 수행한다고 가정함
	if (damage>=max_damage) DeleteBarrier();
}

void Barrier2(
	float x0, float y0,        // 보호막의 접촉 판정 영역
	float x1, float y1,        // (좌상좌표, 우하좌표)
	float bx0[], float by0[],  // 탄의 접촉 판정 영역
	float bx1[], float by1[],  // (좌상좌표, 우하좌표)
	int num_bullet,            // 탄의 갯수
	float ex0[], float ey0[],  // 적기의 접촉 판정 영역
	float ex1[], float ey1[],  // (좌상좌표, 우하좌표)
	int num_enemy,             // 적기의 갯수
	int& energy,               // 보호막의 에너지
	bool barrier_button        // 보호막 버튼의 상태
) {
	// 보호막의 발동시키기:
	// 보호막 버튼이 눌렸고
	// 또한 에너지가 있을 때는 보호막을 발동시킴
	if (barrier_button && energy>0) {
	
		// 보호막과 탄의 접촉 판정 처리:
		// 탄에 접촉했다면 탄을 지우고 보호막의 에너지를 줄임
		// 탄을 지우는 구체적인 처리는 DeleteBullet함수에서 수행한다고 가정함
		for (int i=0; i<num_bullet && energy>0; i++) {
			if (bx0[i]<x1 && x0<bx1[i] && 
				by0[i]<y1 && y0<by1[i]) {
				DeleteBullet(i);
				energy--;
			}
		}

		// 보호막과 적기의 접촉 판정 처리:
		// 적기에 접촉했다면 적기에게 피해를 주고
		// 보호막의 에너지를 줄여줌
		// 적기에게 피해를 주는 구체적인 처리는
		// DamageEnemy함수에서 수행한다고 가정함
		for (int i=0; i<num_enemy && energy>0; i++) {
			if (ex0[i]<x1 && x0<ex1[i] && 
				ey0[i]<y1 && y0<ey1[i]) {
				DamageEnemy(i);
				energy--;
			}
		}

		// 에너지의 소비
		energy--;
	}
}


