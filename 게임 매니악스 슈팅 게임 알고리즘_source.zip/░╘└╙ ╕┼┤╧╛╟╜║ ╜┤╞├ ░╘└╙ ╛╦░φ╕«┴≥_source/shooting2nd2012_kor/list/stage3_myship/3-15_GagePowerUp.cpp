bool PickItem();
void PowerUp(int id);

// 파워업의 종류
typedef enum {
	NONE,  // 커서가 없는 상태
	SPEED, MISSILE, DOUBLE, 
	LASER, OPTION, BARRIER, 
	END    // 게이지의 맨 오른쪽을 나타냄
} POWER_UP_TYPE;

// 게이지를 사용한 파워업
void PowerUpGauge(
	bool power_up_button  // 파워업 버튼의 입력
) {
	static POWER_UP_TYPE cursor=NONE;  // 커서의 위치
	
	// 아이템을 주웠을 때의 처리:
	// 아이템을 주웄으면 커서를 오른쪽으로 한 칸 이동시킴
	// 맨 오른쪽까지 움직였다면 맨 왼쪽으로 되돌림
	// 아이템 취득 판정 처리는 PickItem함수로 처리한다고 가정함
	if (PickItem()) {
		cursor++;
		if (cursor==END) cursor=SPEED;
	}
	
	// 파워업의 처리:
	// 버튼이 눌렸다면 현재 커서가 가리키는 파워업을 적용한다
	// 구체적인 파워업 처리는 PowerUp함수로 처리한다고 가정함
	if (power_up_button) {
		PowerUp(cursor);
	}
}

