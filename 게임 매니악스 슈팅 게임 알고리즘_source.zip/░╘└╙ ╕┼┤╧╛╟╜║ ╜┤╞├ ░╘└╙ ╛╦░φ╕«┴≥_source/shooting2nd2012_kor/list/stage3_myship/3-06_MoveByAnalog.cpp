void MoveByAnalog(
	float& x, float& y,    // 메인 캐릭터의 좌표(X방향, Y방향)
	float speed,           // 메인 캐릭터의 최고속도
	int jx, int jy,        // 스틱의 입력값(X방향, Y방향)
	int range, int margin  // 입력값의 범위 (최대치), 마진
) {
	// X방향으로 이동
	if (jx<=-range+margin) x-=speed; else
	if (+range-margin<=jx) x+=speed; else
	if (jx<-margin) x+=speed*(jx+margin)/(range-margin*2); else
	if (+margin<jx) x+=speed*(jx-margin)/(range-margin*2);
	
	// Y방향으로 이동
	if (jy<=-range+margin) y-=speed; else
	if (+range-margin<=jy) y+=speed; else
	if (jy<-margin) y+=speed*(jy+margin)/(range-margin*2); else
	if (+margin<jy) y+=speed*(jy-margin)/(range-margin*2);
}

