void MoveMyShip(
	float& x, float& y,    // 메인 캐릭터의 좌표(X방향, Y방향)
	float speed,           // 메인 캐릭터의 속도
	bool up, bool down,    // 상하 방향으로의 스틱 입력
	bool left, bool right  // 좌우 방향으로의 스틱 입력
) {
	if (up   ) y-=speed;
	if (down ) y+=speed;
	if (left ) x-=speed;
	if (right) x+=speed;
}

