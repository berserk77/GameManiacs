void SpeedControlByButton(
	float& speed,     // 스피드
	float accel,      // 스피드업 간격
	float max_speed,  // 최고 속도
	float min_speed,  // 최저 속도
	bool button       // 속도 조절 버튼의 입력
) {
	// 버튼의 이전 상태
	static bool prev_button=false;
	
	// 버튼을 한 번 뗀 후에 눌렀을 경우:
	// 속도 조절을 수행함
	if (!prev_button && button) {
		if (speed>=max_speed) speed=min_speed;
		else speed+=accel;
	}
	
	// 버튼의 상태를 기록하기
	prev_button=button;
}

void SpeedControlByItem(
	float& speed,          // 스피드
	float max_speed,       // 최고 속도
	float min_speed,       // 최저 속도
	float x0, float y0,    // 취득 판정 영역의 좌상좌표
	float x1, float y1,    // 취득 판정 영역의 우하좌표
	float ix0, float iy0,  // 아이템의 취득 판정 영역의 좌상좌표
	float ix1, float iy1,  // 아이템의 취득 판정 영역의 우하좌표
	float accel            // 스피드 업, 다운의 간격
) {
	// 아이템을 주웠을 때의 처리:
	// 접촉 판정 처리를 수행하여, 접촉하였다면
	// 스피드 업 혹은 스피드 다운을 수행한다
	if (ix0<x1 && x0<ix1 && iy0<y1 && y0<iy1) {
		speed+=accel;
		
		// 아래와 같이 하면
		// 스피드 다운을 단지 하나 취득함으로서 
		// 스피드가 최저 속도가 되게 할 수 있음
		// if (accel<0) speed=min_speed;
		
		// 스피드가 최고 속도나 최저 속도를 넘었을 때 보정해 주기
		if (speed>max_speed) speed=max_speed;
		if (speed<min_speed) speed=min_speed;
	}
}


