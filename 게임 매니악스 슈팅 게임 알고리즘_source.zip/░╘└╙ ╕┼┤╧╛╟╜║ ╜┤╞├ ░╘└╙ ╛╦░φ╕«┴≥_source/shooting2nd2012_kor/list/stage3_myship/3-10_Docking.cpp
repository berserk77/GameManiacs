bool EnemyDestroyed();
bool Catched();

// 아군 캐릭터의 상태 (포획, 부유, 합체)
typedef enum {
	CAPTURED, FLOATING, DOCKED
} DOCKING_STATE;

// 합체에 관한 처리
void Docking(
	float& cx, float& cy,  // 아군 캐릭터의 좌표
	float ex, float ey,    // 적기의 좌표
	float mx, float my,    // 메인 캐릭터의 좌표
	DOCKING_STATE& state   // 아군 캐릭터의 상태
) {
	// 아군 캐릭터의 상태에 따라 분기하기
	switch (state) {
		
		// 포획:
		// 적기와 함께 움직임.
		// 적기가 파괴되면 부유상태로 이동함.
		// 적기의 파괴 판정은 EnemyDestroyed함수로 수행한다고 가정함
		case CAPTURED:
			cx=ex; cy=ey;
			if (EnemyDestroyed()) state=FLOATING;
			break;
		
		// 부유:
		// 자유롭게 움직임.
		// 여기서는 화면 아래 방향으로 직진하기로 함.
		// 메인 캐릭터에 접촉하면 합체 상태로 이동함.
		// 접촉 판정 처리는 Catched함수에서 수행하기로 가정함.
		case FLOATING:
			cy++;
			if (Catched()) state=DOCKED;
			break;
		
		// 합체:
		// 메인 캐릭터와 함께 움직임
		case DOCKED:
			cx=mx; cy=my;
			break;
	}
}

