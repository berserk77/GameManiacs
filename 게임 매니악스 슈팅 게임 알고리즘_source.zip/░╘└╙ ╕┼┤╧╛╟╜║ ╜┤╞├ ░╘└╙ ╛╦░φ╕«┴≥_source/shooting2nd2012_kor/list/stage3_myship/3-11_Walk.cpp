// 메인 캐릭터의 상태(보행, 상승, 하강)
typedef enum {
	WALKING, JUMP_UP, JUMP_DOWN
} MYSHIP_STATE;

// 메인 캐릭터의 움직임
void Walk(
	float& x, float& y,     // 메인 캐릭터의 좌표
	float speed,            // 메인 캐릭터의 속도
	bool left, bool right,  // 스틱 입력(좌우)
	bool jump_button        // 점프 버튼의 입력
) {
	static MYSHIP_STATE state=WALKING;  // 메인 캐릭터의 상태
	static int time;                    // 점프 시간
	
	// 좌오 이동
	if (left ) x-=speed;
	if (right) x+=speed;

	// 상태에 따라 분기
	switch (state) {

		// 보행:
		// 점프 버튼이 눌렸다면 상승 상태로 이동함.
		case WALKING:
			if (jump_button) {
				state=JUMP_UP;
				time=40;
			}
			break;
		
		// 상승:
		// 일정 시간 상승했다면 하강 상태로 이동함.
		case JUMP_UP:
			y-=speed;
			if (time==0) {
				state=JUMP_DOWN;
				time=40;
			} else time--;
			break;
		
		// 하강:
		// 일정 시간 하강했다면 보행 상태로 되돌아 감.
		case JUMP_DOWN:
			y+=speed;
			if (time==0) state=WALKING; else time--;
			break;
	}
}
