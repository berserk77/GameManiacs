void WaveEffect();

void Underwater1(
	float& x, float& y,  // 메인 캐릭터의 좌표
	float vx, float vy,  // 메인 캐릭터의 속도 벡터
	float h              // 수면의 높이
) {
	// 공중의 경우:
	// 보통 속도로 이동함.
	if (y<h) {
		x+=vx; y+=vy;
	}

	// 수중의 경우:
	// 속도를 느리게 조절함. 여기서는 공중의 절반으로 함.
	else {
		x+=vx/2; y+=vy/2;
	}
}

void Underwater2(
	float& x, float& y,        // 메인 캐릭터의 좌표
	float x0, float y0,        // 메인 캐릭터의 좌상좌표
	float x1, float y1,        // 메인 캐릭터의 우하좌표
	float vx, float vy,        // 메인 캐릭터의 속도 벡터
	float wx0[], float wy0[],  // 수면의 접촉 판정 영역
	float wx1[], float wy1[],  // (좌상좌표, 우하좌표)
	int num_water              // 수면의 접촉 판정 영역의 갯수
) {
	// 메인 캐릭터가 수중에 있는지 공중에 있는지 체크
	int i;
	for (i=0; i<num_water; i++) {
		if (wx0[i]<=x0 && x1<=wx1[i] && 
			wy0[i]<=y0 && y1<=wy1[i]) break;
	}
	
	// 메인 캐릭터가 수중이 있을 경우:
	// 속도를 느리게 조절함. 여기서는 공중의 절반으로 함.
	if (i<num_water) {
		x+=vx/2; y+=vy/2;
	}
	
	// 메인 캐릭터가 수중이 있지 않을 경우:
	// 보통 속도로 이동함.
	else {
		x+=vx; y+=vy;
		
		// 메인 캐릭터가 수면에 접촉했는지 체크
		for (i=0; i<num_water; i++) {
			if (wx0[i]<x1 && x0<wx1[i] && 
				wy0[i]<y1 && y0<wy1[i]) break;
		}

		// 메인 캐릭터가 수면에 접촉했을 경우:
		// 접촉한 장소의 물이 튀는 듯한 효과를 표시하기.
		// 구체적인 처리는 WaveEffect함수에서 수행하기로 함.
		if (i<num_water) WaveEffect();
	}
}

